package com.mrcrayfish.device.util;

import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

public class TileEntityUtil 
{
	public static void markBlockForUpdate(World world, BlockPos pos)
	{
		world.func_184138_a(pos, world.func_180495_p(pos), world.func_180495_p(pos), 3);
	}
}
