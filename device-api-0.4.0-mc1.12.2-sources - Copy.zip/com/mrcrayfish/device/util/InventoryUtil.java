package com.mrcrayfish.device.util;

import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;

public class InventoryUtil
{
	public static int getItemAmount(EntityPlayer player, Item item)
	{
		int amount = 0;
		for(int i = 0; i < player.field_71071_by.func_70302_i_(); i++)
		{
			ItemStack stack = player.field_71071_by.func_70301_a(i);
			if(stack != null && stack.func_77973_b() == item)
			{
				amount += stack.func_190916_E();
			}
		}
		return amount;
	}
	
	public static boolean hasItemAndAmount(EntityPlayer player, Item item, int amount)
	{
		int count = 0;
		for(ItemStack stack : player.field_71071_by.field_70462_a)
		{
			if(stack != null && stack.func_77973_b() == item)
			{
				count += stack.func_190916_E();
			}
		}
		return amount <= count;
	}
	
	public static boolean removeItemWithAmount(EntityPlayer player, Item item, int amount)
	{
		if(hasItemAndAmount(player, item, amount))
		{
			for(int i = 0; i < player.field_71071_by.func_70302_i_(); i++)
			{
				ItemStack stack = player.field_71071_by.func_70301_a(i);
				if(stack != null && stack.func_77973_b() == item)
				{
					if(amount - stack.func_190916_E() < 0)
					{
						stack.func_190918_g(amount);
						return true;
					}
					else
					{
						amount -= stack.func_190916_E();
						player.field_71071_by.field_70462_a.set(i, ItemStack.field_190927_a);
						if(amount == 0) return true;
					}
				}
			}
		}
		return false;
	}
}
