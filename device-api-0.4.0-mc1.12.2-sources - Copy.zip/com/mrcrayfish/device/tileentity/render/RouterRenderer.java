package com.mrcrayfish.device.tileentity.render;

import com.mrcrayfish.device.block.BlockPrinter;
import com.mrcrayfish.device.block.BlockRouter;
import com.mrcrayfish.device.core.network.NetworkDevice;
import com.mrcrayfish.device.core.network.Router;
import com.mrcrayfish.device.init.DeviceBlocks;
import com.mrcrayfish.device.tileentity.TileEntityRouter;
import com.mrcrayfish.device.util.CollisionHelper;
import net.minecraft.block.state.IBlockState;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.BufferBuilder;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.OpenGlHelper;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.tileentity.TileEntitySpecialRenderer;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import org.lwjgl.opengl.GL11;

import java.util.Collection;

/**
 * Author: MrCrayfish
 */
public class RouterRenderer extends TileEntitySpecialRenderer<TileEntityRouter>
{
    @Override
    public void func_192841_a(TileEntityRouter te, double x, double y, double z, float partialTicks, int destroyStage, float alpha)
    {
        IBlockState state = te.func_145831_w().func_180495_p(te.func_174877_v());
        if(state.func_177230_c() != DeviceBlocks.ROUTER)
            return;

        if(te.isDebug())
        {
            GlStateManager.func_179147_l();
            OpenGlHelper.func_148821_a(770, 771, 1, 0);
            GlStateManager.func_179140_f();
            GlStateManager.func_179090_x();
            GlStateManager.func_179141_d();
            GlStateManager.func_179094_E();
            {
                GlStateManager.func_179137_b(x, y, z);
                Router router = te.getRouter();
                BlockPos routerPos = router.getPos();

                Vec3d linePositions = getLineStartPosition(state);
                final double startLineX = linePositions.field_72450_a;
                final double startLineY = linePositions.field_72448_b;
                final double startLineZ = linePositions.field_72449_c;

                Tessellator tessellator = Tessellator.func_178181_a();
                BufferBuilder buffer = tessellator.func_178180_c();

                final Collection<NetworkDevice> DEVICES = router.getConnectedDevices(Minecraft.func_71410_x().field_71441_e);
                DEVICES.forEach(networkDevice ->
                {
                    BlockPos devicePos = networkDevice.getPos();

                    GL11.glLineWidth(14F);
                    buffer.func_181668_a(GL11.GL_LINES, DefaultVertexFormats.field_181706_f);
                    buffer.func_181662_b(startLineX, startLineY, startLineZ).func_181666_a(0.0F, 0.0F, 0.0F, 0.5F).func_181675_d();
                    buffer.func_181662_b((devicePos.func_177958_n() - routerPos.func_177958_n()) + 0.5F, (devicePos.func_177956_o() - routerPos.func_177956_o()), (devicePos.func_177952_p() - routerPos.func_177952_p()) + 0.5F).func_181666_a(1.0F, 1.0F, 1.0F, 0.35F).func_181675_d();
                    tessellator.func_78381_a();

                    GL11.glLineWidth(4F);
                    buffer.func_181668_a(GL11.GL_LINES, DefaultVertexFormats.field_181706_f);
                    buffer.func_181662_b(startLineX, startLineY, startLineZ).func_181666_a(0.0F, 0.0F, 0.0F, 0.5F).func_181675_d();
                    buffer.func_181662_b((devicePos.func_177958_n() - routerPos.func_177958_n()) + 0.5F, (devicePos.func_177956_o() - routerPos.func_177956_o()), (devicePos.func_177952_p() - routerPos.func_177952_p()) + 0.5F).func_181666_a(0.0F, 1.0F, 0.0F, 0.5F).func_181675_d();
                    tessellator.func_78381_a();
                });
            }
            GlStateManager.func_179121_F();
            GlStateManager.func_179084_k();
            GlStateManager.func_179118_c();
            GlStateManager.func_179145_e();
            GlStateManager.func_179098_w();
        }
    }

    private Vec3d getLineStartPosition(IBlockState state)
    {
        float lineX = 0.5F;
        float lineY = 0.1F;
        float lineZ = 0.5F;

        if(state.func_177229_b(BlockRouter.VERTICAL))
        {
            double[] fixedPosition = CollisionHelper.fixRotation(state.func_177229_b(BlockPrinter.field_185512_D), 14 * 0.0625, 0.5, 14 * 0.0625, 0.5);
            lineX = (float) fixedPosition[0];
            lineY = 0.35F;
            lineZ = (float) fixedPosition[1];
        }

        return new Vec3d(lineX, lineY, lineZ);
    }
}
