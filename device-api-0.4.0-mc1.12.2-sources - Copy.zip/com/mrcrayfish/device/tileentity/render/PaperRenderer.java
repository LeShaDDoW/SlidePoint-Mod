package com.mrcrayfish.device.tileentity.render;

import com.mrcrayfish.device.DeviceConfig;
import com.mrcrayfish.device.api.print.IPrint;
import com.mrcrayfish.device.api.print.PrintingManager;
import com.mrcrayfish.device.block.BlockPaper;
import com.mrcrayfish.device.init.DeviceBlocks;
import com.mrcrayfish.device.tileentity.TileEntityPaper;
import net.minecraft.block.state.IBlockState;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.BufferBuilder;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.tileentity.TileEntitySpecialRenderer;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.EnumFacing;
import net.minecraftforge.common.util.Constants;
import org.lwjgl.opengl.GL11;

/**
 * Author: MrCrayfish
 */
public class PaperRenderer extends TileEntitySpecialRenderer<TileEntityPaper>
{
    @Override
    public void func_192841_a(TileEntityPaper te, double x, double y, double z, float partialTicks, int destroyStage, float alpha)
    {
        GlStateManager.func_179094_E();
        {
            GlStateManager.func_179137_b(x, y, z);
            GlStateManager.func_179137_b(0.5, 0.5, 0.5);
            IBlockState state = te.func_145831_w().func_180495_p(te.func_174877_v());
            if(state.func_177230_c() != DeviceBlocks.PAPER) return;
            GlStateManager.func_179114_b(state.func_177229_b(BlockPaper.field_185512_D).func_176736_b() * -90F + 180F, 0, 1, 0);
            GlStateManager.func_179114_b(-te.getRotation(), 0, 0, 1);
            GlStateManager.func_179137_b(-0.5, -0.5, -0.5);

            IPrint print = te.getPrint();
            if(print != null)
            {
                NBTTagCompound data = print.toTag();
                if(data.func_150297_b("pixels", Constants.NBT.TAG_INT_ARRAY) && data.func_150297_b("resolution", Constants.NBT.TAG_INT))
                {
                    Minecraft.func_71410_x().func_110434_K().func_110577_a(PrinterRenderer.ModelPaper.TEXTURE);
                    if(DeviceConfig.isRenderPrinted3D() && !data.func_74767_n("cut"))
                    {
                        drawCuboid(0, 0, 0, 16, 16, 1);
                    }

                    GlStateManager.func_179137_b(0, 0, DeviceConfig.isRenderPrinted3D() ? 0.0625 : 0.001);

                    GlStateManager.func_179094_E();
                    {
                        IPrint.Renderer renderer = PrintingManager.getRenderer(print);
                        renderer.render(data);
                    }
                    GlStateManager.func_179121_F();

                    GlStateManager.func_179094_E();
                    {
                        if(DeviceConfig.isRenderPrinted3D() && data.func_74767_n("cut"))
                        {
                            NBTTagCompound tag = print.toTag();
                            drawPixels(tag.func_74759_k("pixels"), tag.func_74762_e("resolution"), tag.func_74767_n("cut"));
                        }
                    }
                    GlStateManager.func_179121_F();
                }
            }
        }
        GlStateManager.func_179121_F();
    }

    private static void drawCuboid(double x, double y, double z, double width, double height, double depth)
    {
        x /= 16;
        y /= 16;
        z /= 16;
        width /= 16;
        height /= 16;
        depth /= 16;
        GlStateManager.func_179140_f();
        GlStateManager.func_179091_B();
        GlStateManager.func_187432_a(0.0F, 1.0F, 0.0F);
        drawQuad(x + (1 - width), y, z, x + width + (1 - width), y + height, z, EnumFacing.NORTH);
        drawQuad(x + 1, y, z, x + 1, y + height, z + depth, EnumFacing.EAST);
        drawQuad(x + width + 1 - (width + width), y, z + depth, x + width + 1 - (width + width), y + height, z, EnumFacing.WEST);
        drawQuad(x + (1 - width), y, z + depth, x + width + (1 - width), y, z, EnumFacing.DOWN);
        drawQuad(x + (1 - width), y + height, z, x + width + (1 - width), y, z + depth, EnumFacing.UP);
        GlStateManager.func_179101_C();
        GlStateManager.func_179145_e();
    }

    private static void drawQuad(double xFrom, double yFrom, double zFrom, double xTo, double yTo, double zTo, EnumFacing facing)
    {
        double textureWidth = Math.abs(xTo - xFrom);
        double textureHeight = Math.abs(yTo - yFrom);
        double textureDepth = Math.abs(zTo - zFrom);

        Tessellator tessellator = Tessellator.func_178181_a();
        BufferBuilder buffer = tessellator.func_178180_c();
        buffer.func_181668_a(GL11.GL_QUADS, DefaultVertexFormats.field_181707_g);
        switch(facing.func_176740_k())
        {
            case X:
                buffer.func_181662_b(xFrom, yFrom, zFrom).func_187315_a(1 - xFrom + textureDepth, 1 - yFrom + textureHeight).func_181675_d();
                buffer.func_181662_b(xFrom, yTo, zFrom).func_187315_a(1 - xFrom + textureDepth, 1 - yFrom).func_181675_d();
                buffer.func_181662_b(xTo, yTo, zTo).func_187315_a(1 - xFrom, 1 - yFrom).func_181675_d();
                buffer.func_181662_b(xTo, yFrom, zTo).func_187315_a(1 - xFrom, 1 - yFrom + textureHeight).func_181675_d();
                break;
            case Y:
                buffer.func_181662_b(xFrom, yFrom, zFrom).func_187315_a(1 - xFrom + textureWidth, 1 - yFrom + textureDepth).func_181675_d();
                buffer.func_181662_b(xFrom, yFrom, zTo).func_187315_a(1 - xFrom + textureWidth, 1 - yFrom).func_181675_d();
                buffer.func_181662_b(xTo, yFrom, zTo).func_187315_a(1 - xFrom, 1 - yFrom).func_181675_d();
                buffer.func_181662_b(xTo, yFrom, zFrom).func_187315_a(1 - xFrom, 1 - yFrom + textureDepth).func_181675_d();
                break;
            case Z:
                buffer.func_181662_b(xFrom, yFrom, zFrom).func_187315_a(1 - xFrom + textureWidth, 1 - yFrom + textureHeight).func_181675_d();
                buffer.func_181662_b(xFrom, yTo, zFrom).func_187315_a(1 - xFrom + textureWidth, 1 - yFrom).func_181675_d();
                buffer.func_181662_b(xTo, yTo, zTo).func_187315_a(1 - xFrom, 1 - yFrom).func_181675_d();
                buffer.func_181662_b(xTo, yFrom, zTo).func_187315_a(1 - xFrom, 1 - yFrom + textureHeight).func_181675_d();
                break;
        }
        tessellator.func_78381_a();
    }

    private static void drawPixels(int[] pixels, int resolution, boolean cut)
    {
        double scale = 16 / (double) resolution;
        for(int i = 0; i < resolution; i++)
        {
            for(int j = 0; j < resolution; j++)
            {
                float a = (float) Math.floor((pixels[j + i * resolution] >> 24 & 255) / 255.0F);
                if(a < 1.0F)
                {
                    if(cut) continue;
                    GlStateManager.func_179124_c(1.0F, 1.0F, 1.0F);
                }
                else
                {
                    float r = (float) (pixels[j + i * resolution] >> 16 & 255) / 255.0F;
                    float g = (float) (pixels[j + i * resolution] >> 8 & 255) / 255.0F;
                    float b = (float) (pixels[j + i * resolution] & 255) / 255.0F;
                    GlStateManager.func_179131_c(r, g, b, a);
                }
                drawCuboid(j * scale - (resolution - 1) * scale, -i * scale + (resolution - 1) * scale, -1, scale, scale, 1);
            }
        }
    }
}
