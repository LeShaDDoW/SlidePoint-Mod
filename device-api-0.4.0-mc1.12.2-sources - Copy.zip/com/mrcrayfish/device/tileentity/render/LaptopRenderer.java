package com.mrcrayfish.device.tileentity.render;

import com.mrcrayfish.device.block.BlockLaptop;
import com.mrcrayfish.device.init.DeviceBlocks;
import com.mrcrayfish.device.init.DeviceItems;
import com.mrcrayfish.device.tileentity.TileEntityLaptop;
import net.minecraft.block.state.IBlockState;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.BlockRendererDispatcher;
import net.minecraft.client.renderer.BufferBuilder;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.block.model.IBakedModel;
import net.minecraft.client.renderer.texture.TextureMap;
import net.minecraft.client.renderer.tileentity.TileEntitySpecialRenderer;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.item.ItemStack;
import net.minecraft.util.math.BlockPos;

public class LaptopRenderer extends TileEntitySpecialRenderer<TileEntityLaptop>
{
	private Minecraft mc = Minecraft.func_71410_x();

	private EntityItem entityItem = new EntityItem(Minecraft.func_71410_x().field_71441_e, 0D, 0D, 0D);

	@Override
	public void func_192841_a(TileEntityLaptop te, double x, double y, double z, float partialTicks, int destroyStage, float alpha)
	{
		IBlockState state = DeviceBlocks.LAPTOP.func_176223_P().func_177226_a(BlockLaptop.TYPE, BlockLaptop.Type.SCREEN);
		BlockPos pos = te.func_174877_v();
		
		func_147499_a(TextureMap.field_110575_b);
		GlStateManager.func_179094_E();
		{
			GlStateManager.func_179137_b(x, y, z);

			if(te.isExternalDriveAttached())
			{
				GlStateManager.func_179094_E();
				{
					GlStateManager.func_179137_b(0.5, 0, 0.5);
					GlStateManager.func_179114_b(te.func_145832_p() * -90F - 90F, 0, 1, 0);
					GlStateManager.func_179137_b(-0.5, 0, -0.5);
					GlStateManager.func_179137_b(0.595, -0.2075, -0.005);
					entityItem.field_70290_d = 0.0F;
					entityItem.func_92058_a(new ItemStack(DeviceItems.FLASH_DRIVE, 1, te.getExternalDriveColor().func_176765_a()));
					Minecraft.func_71410_x().func_175598_ae().func_188391_a(entityItem, 0.0D, 0.0D, 0.0D, 0.0F, 0.0F, false);
					GlStateManager.func_179137_b(0.1, 0, 0);
				}
				GlStateManager.func_179121_F();
			}

			GlStateManager.func_179094_E();
			{
				GlStateManager.func_179137_b(0.5, 0, 0.5);
				GlStateManager.func_179114_b(te.func_145832_p() * -90F + 180F, 0, 1, 0);
				GlStateManager.func_179137_b(-0.5, 0, -0.5);
				GlStateManager.func_179137_b(0, 0.0625, 0.25);
				GlStateManager.func_179114_b(te.getScreenAngle(partialTicks), 1, 0, 0);

				GlStateManager.func_179140_f();
				Tessellator tessellator = Tessellator.func_178181_a();
				BufferBuilder buffer = tessellator.func_178180_c();
				buffer.func_181668_a(7, DefaultVertexFormats.field_176600_a);
				buffer.func_178969_c(-pos.func_177958_n(), -pos.func_177956_o(), -pos.func_177952_p());

				BlockRendererDispatcher blockrendererdispatcher = Minecraft.func_71410_x().func_175602_ab();
				IBakedModel ibakedmodel = mc.func_175602_ab().func_175023_a().func_178125_b(state);
				blockrendererdispatcher.func_175019_b().func_178267_a(func_178459_a(), ibakedmodel, state, pos, buffer, false);

				buffer.func_178969_c(0.0D, 0.0D, 0.0D);
				tessellator.func_78381_a();
				GlStateManager.func_179145_e();
			}
			GlStateManager.func_179121_F();
		 }
		 GlStateManager.func_179121_F();
	}
}
