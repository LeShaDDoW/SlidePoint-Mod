package com.mrcrayfish.device.tileentity.render;

import com.mrcrayfish.device.block.BlockOfficeChair;
import com.mrcrayfish.device.init.DeviceBlocks;
import com.mrcrayfish.device.tileentity.TileEntityOfficeChair;
import net.minecraft.block.state.IBlockState;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.BlockRendererDispatcher;
import net.minecraft.client.renderer.BufferBuilder;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.block.model.IBakedModel;
import net.minecraft.client.renderer.texture.TextureMap;
import net.minecraft.client.renderer.tileentity.TileEntitySpecialRenderer;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.math.BlockPos;

/**
 * Author: MrCrayfish
 */
public class OfficeChairRenderer extends TileEntitySpecialRenderer<TileEntityOfficeChair>
{
    private Minecraft mc = Minecraft.func_71410_x();

    @Override
    public void func_192841_a(TileEntityOfficeChair te, double x, double y, double z, float partialTicks, int destroyStage, float alpha)
    {
        BlockPos pos = te.func_174877_v();
        IBlockState tempState = te.func_145831_w().func_180495_p(pos);
        if(tempState.func_177230_c() != DeviceBlocks.OFFICE_CHAIR)
        {
            return;
        }

        GlStateManager.func_179094_E();
        {
            GlStateManager.func_179137_b(x, y, z);

            GlStateManager.func_179137_b(0.5, 0, 0.5);
            GlStateManager.func_179114_b(-te.getRotation(), 0, 1, 0);
            GlStateManager.func_179137_b(-0.5, 0, -0.5);

            IBlockState state = tempState.func_177230_c().func_176221_a(tempState, te.func_145831_w(), pos).func_177226_a(BlockOfficeChair.field_185512_D, EnumFacing.NORTH).func_177226_a(BlockOfficeChair.TYPE, BlockOfficeChair.Type.SEAT);

            GlStateManager.func_179140_f();
            GlStateManager.func_179098_w();

            func_147499_a(TextureMap.field_110575_b);

            Tessellator tessellator = Tessellator.func_178181_a();

            BufferBuilder buffer = tessellator.func_178180_c();
            buffer.func_181668_a(7, DefaultVertexFormats.field_176600_a);
            buffer.func_178969_c(-te.func_174877_v().func_177958_n(), -te.func_174877_v().func_177956_o(), -te.func_174877_v().func_177952_p());

            BlockRendererDispatcher blockrendererdispatcher = Minecraft.func_71410_x().func_175602_ab();
            IBakedModel ibakedmodel = mc.func_175602_ab().func_175023_a().func_178125_b(state);
            blockrendererdispatcher.func_175019_b().func_178267_a(func_178459_a(), ibakedmodel, state, te.func_174877_v(), buffer, false);

            buffer.func_178969_c(0.0D, 0.0D, 0.0D);
            tessellator.func_78381_a();

            GlStateManager.func_179145_e();
        }
        GlStateManager.func_179121_F();
    }
}
