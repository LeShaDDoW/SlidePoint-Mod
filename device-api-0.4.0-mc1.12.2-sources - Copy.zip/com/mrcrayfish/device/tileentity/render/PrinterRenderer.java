package com.mrcrayfish.device.tileentity.render;

import com.mrcrayfish.device.Reference;
import com.mrcrayfish.device.api.print.IPrint;
import com.mrcrayfish.device.api.print.PrintingManager;
import com.mrcrayfish.device.block.BlockPrinter;
import com.mrcrayfish.device.init.DeviceBlocks;
import com.mrcrayfish.device.tileentity.TileEntityPrinter;
import net.minecraft.block.state.IBlockState;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.tileentity.TileEntitySpecialRenderer;
import net.minecraft.entity.Entity;
import net.minecraft.util.ResourceLocation;

import java.awt.*;

/**
 * Author: MrCrayfish
 */
public class PrinterRenderer extends TileEntitySpecialRenderer<TileEntityPrinter>
{
    private static final ModelPaper MODEL_PAPER = new ModelPaper();

    @Override
    public void func_192841_a(TileEntityPrinter te, double x, double y, double z, float partialTicks, int destroyStage, float alpha)
    {
        IBlockState state = te.func_145831_w().func_180495_p(te.func_174877_v());
        if(state.func_177230_c() != DeviceBlocks.PRINTER)
            return;

        GlStateManager.func_179094_E();
        {
            GlStateManager.func_179131_c(1.0F, 1.0F, 1.0F, 1.0F);
            GlStateManager.func_179137_b(x, y, z);

            if(te.hasPaper())
            {
                GlStateManager.func_179094_E();
                {
                    GlStateManager.func_179137_b(0.5, 0.5, 0.5);
                    GlStateManager.func_179114_b(state.func_177229_b(BlockPrinter.field_185512_D).func_176736_b() * -90F, 0, 1, 0);
                    GlStateManager.func_179114_b(22.5F, 1, 0, 0);
                    GlStateManager.func_179137_b(0, 0, 0.4);
                    GlStateManager.func_179137_b(-11 * 0.015625, -13 * 0.015625, -0.5 * 0.015625);
                    MODEL_PAPER.func_78088_a(null, 0F, 0F, 0F, 0F, 0F, 0.015625F);
                }
                GlStateManager.func_179121_F();
            }

            GlStateManager.func_179094_E();
            {
                if(te.isLoading())
                {
                    GlStateManager.func_179137_b(0.5, 0.5, 0.5);
                    GlStateManager.func_179114_b(state.func_177229_b(BlockPrinter.field_185512_D).func_176736_b() * -90F, 0, 1, 0);
                    GlStateManager.func_179114_b(22.5F, 1, 0, 0);
                    double progress = Math.max(-0.4, -0.4 + (0.4 * ((double) (te.getRemainingPrintTime() - 10) / 20)));
                    GlStateManager.func_179137_b(0, progress, 0.36875);
                    GlStateManager.func_179137_b(-11 * 0.015625, -13 * 0.015625, -0.5 * 0.015625);
                    MODEL_PAPER.func_78088_a(null, 0F, 0F, 0F, 0F, 0F, 0.015625F);
                }
                else if(te.isPrinting())
                {
                    GlStateManager.func_179137_b(0.5, 0.078125, 0.5);
                    GlStateManager.func_179114_b(state.func_177229_b(BlockPrinter.field_185512_D).func_176736_b() * -90F, 0, 1, 0);
                    GlStateManager.func_179114_b(90F, 1, 0, 0);
                    double progress = -0.35 + (0.50 * ((double) (te.getRemainingPrintTime() - 20) / te.getTotalPrintTime()));
                    GlStateManager.func_179137_b(0, progress, 0);
                    GlStateManager.func_179137_b(-11 * 0.015625, -13 * 0.015625, -0.5 * 0.015625);
                    MODEL_PAPER.func_78088_a(null, 0F, 0F, 0F, 0F, 0F, 0.015625F);

                    GlStateManager.func_179137_b(0.3225, 0.085, -0.001);
                    GlStateManager.func_179114_b(180F, 0, 1, 0);
                    GlStateManager.func_179139_a(0.3, 0.3, 0.3);

                    IPrint print = te.getPrint();
                    if(print != null)
                    {
                        IPrint.Renderer renderer = PrintingManager.getRenderer(print);
                        renderer.render(print.toTag());
                    }
                }
            }
            GlStateManager.func_179121_F();

            GlStateManager.func_179094_E();
            {
                GlStateManager.func_179132_a(false);
                GlStateManager.func_179137_b(0.5, 0.5, 0.5);
                GlStateManager.func_179114_b(state.func_177229_b(BlockPrinter.field_185512_D).func_176736_b() * -90F, 0, 1, 0);
                GlStateManager.func_179114_b(180F, 0, 1, 0);
                GlStateManager.func_179137_b(0.0675, 0.005, -0.032);
                GlStateManager.func_179137_b(-6.5 * 0.0625, -3.5 * 0.0625, 3.01 * 0.0625);
                GlStateManager.func_179152_a(0.010416667F, -0.010416667F, 0.010416667F);
                GlStateManager.func_187432_a(0.0F, 0.0F, -0.010416667F);
                GlStateManager.func_179114_b(22.5F, 1, 0, 0);
                Minecraft.func_71410_x().field_71466_p.func_78276_b(Integer.toString(te.getPaperCount()), 0, 0, Color.WHITE.getRGB());
                GlStateManager.func_179131_c(1.0F, 1.0F, 1.0F, 1.0F);
                GlStateManager.func_179132_a(true);
            }
            GlStateManager.func_179121_F();
        }
        GlStateManager.func_179121_F();

        GlStateManager.func_179094_E();
        {
            GlStateManager.func_179137_b(0, -0.5, 0);
            super.func_192841_a(te, x, y, z, partialTicks, destroyStage, alpha);
        }
        GlStateManager.func_179121_F();
    }

    public static class ModelPaper extends ModelBase
    {
        public static final ResourceLocation TEXTURE = new ResourceLocation(Reference.MOD_ID, "textures/model/paper.png");

        private ModelRenderer box = new ModelRenderer(this, 0, 0).func_78789_a(0, 0, 0, 22, 30, 1);

        @Override
        public void func_78088_a(Entity entityIn, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch, float scale)
        {
            Minecraft.func_71410_x().func_110434_K().func_110577_a(TEXTURE);
            box.func_78785_a(scale);
        }
    }
}
