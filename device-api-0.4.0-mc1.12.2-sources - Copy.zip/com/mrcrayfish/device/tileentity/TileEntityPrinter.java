package com.mrcrayfish.device.tileentity;

import com.mrcrayfish.device.DeviceConfig;
import com.mrcrayfish.device.api.print.IPrint;
import com.mrcrayfish.device.block.BlockPrinter;
import com.mrcrayfish.device.init.DeviceSounds;
import com.mrcrayfish.device.util.CollisionHelper;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.init.Items;
import net.minecraft.init.SoundEvents;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.nbt.NBTTagList;
import net.minecraft.util.SoundCategory;
import net.minecraftforge.common.util.Constants;

import java.util.ArrayDeque;
import java.util.Deque;

import static com.mrcrayfish.device.tileentity.TileEntityPrinter.State.*;

/**
 * Author: MrCrayfish
 */
public class TileEntityPrinter extends TileEntityNetworkDevice.Colored
{
    private State state = IDLE;

    private Deque<IPrint> printQueue = new ArrayDeque<>();
    private IPrint currentPrint;

    private int totalPrintTime;
    private int remainingPrintTime;
    private int paperCount = 0;

    @Override
    public void func_73660_a()
    {
        if(!field_145850_b.field_72995_K)
        {
            if(remainingPrintTime > 0)
            {
                if(remainingPrintTime % 20 == 0 || state == LOADING_PAPER)
                {
                    pipeline.func_74768_a("remainingPrintTime", remainingPrintTime);
                    sync();
                    if(remainingPrintTime != 0 && state == PRINTING)
                    {
                        field_145850_b.func_184133_a(null, field_174879_c, DeviceSounds.PRINTER_PRINTING, SoundCategory.BLOCKS, 0.5F, 1.0F);
                    }
                }
                remainingPrintTime--;
            }
            else
            {
                setState(state.next());
            }
        }

        if(state == IDLE && remainingPrintTime == 0 && currentPrint != null)
        {
            if(!field_145850_b.field_72995_K)
            {
                IBlockState state = field_145850_b.func_180495_p(field_174879_c);
                double[] fixedPosition = CollisionHelper.fixRotation(state.func_177229_b(BlockPrinter.field_185512_D), 0.15, 0.5, 0.15, 0.5);
                EntityItem entity = new EntityItem(field_145850_b, field_174879_c.func_177958_n() + fixedPosition[0], field_174879_c.func_177956_o() + 0.0625, field_174879_c.func_177952_p() + fixedPosition[1], IPrint.generateItem(currentPrint));
                entity.field_70159_w = 0;
                entity.field_70181_x = 0;
                entity.field_70179_y = 0;
                field_145850_b.func_72838_d(entity);
            }
            currentPrint = null;
        }

        if(state == IDLE && currentPrint == null && !printQueue.isEmpty() && paperCount > 0)
        {
            print(printQueue.poll());
        }
    }

    @Override
    public String getDeviceName()
    {
        return "Printer";
    }

    @Override
    public void func_145839_a(NBTTagCompound compound)
    {
        super.func_145839_a(compound);
        if(compound.func_150297_b("currentPrint", Constants.NBT.TAG_COMPOUND))
        {
            currentPrint = IPrint.loadFromTag(compound.func_74775_l("currentPrint"));
        }
        if(compound.func_150297_b("totalPrintTime", Constants.NBT.TAG_INT))
        {
            totalPrintTime = compound.func_74762_e("totalPrintTime");
        }
        if(compound.func_150297_b("remainingPrintTime", Constants.NBT.TAG_INT))
        {
            remainingPrintTime = compound.func_74762_e("remainingPrintTime");
        }
        if(compound.func_150297_b("state", Constants.NBT.TAG_INT))
        {
            state = State.values()[compound.func_74762_e("state")];
        }
        if(compound.func_150297_b("paperCount", Constants.NBT.TAG_INT))
        {
            paperCount = compound.func_74762_e("paperCount");
        }
        if(compound.func_150297_b("queue", Constants.NBT.TAG_LIST))
        {
            printQueue.clear();
            NBTTagList queue = compound.func_150295_c("queue", Constants.NBT.TAG_COMPOUND);
            for(int i = 0; i < queue.func_74745_c(); i++)
            {
                IPrint print = IPrint.loadFromTag(queue.func_150305_b(i));
                printQueue.offer(print);
            }
        }
    }

    @Override
    public NBTTagCompound func_189515_b(NBTTagCompound compound)
    {
        super.func_189515_b(compound);
        compound.func_74768_a("totalPrintTime", totalPrintTime);
        compound.func_74768_a("remainingPrintTime", remainingPrintTime);
        compound.func_74768_a("state", state.ordinal());
        compound.func_74768_a("paperCount", paperCount);
        if(currentPrint != null)
        {
            compound.func_74782_a("currentPrint", IPrint.writeToTag(currentPrint));
        }
        if(!printQueue.isEmpty())
        {
            NBTTagList queue = new NBTTagList();
            printQueue.forEach(print -> {
                queue.func_74742_a(IPrint.writeToTag(print));
            });
            compound.func_74782_a("queue", queue);
        }
        return compound;
    }

    @Override
    public NBTTagCompound writeSyncTag()
    {
        NBTTagCompound tag = super.writeSyncTag();
        tag.func_74768_a("paperCount", paperCount);
        return tag;
    }

    public void setState(State newState)
    {
        if(newState == null)
            return;

        state = newState;
        if(state == PRINTING)
        {
            if(DeviceConfig.isOverridePrintSpeed())
            {
                remainingPrintTime = DeviceConfig.getCustomPrintSpeed() * 20;
            }
            else
            {
                remainingPrintTime = currentPrint.speed() * 20;
            }
        }
        else
        {
            remainingPrintTime = state.animationTime;
        }
        totalPrintTime = remainingPrintTime;

        pipeline.func_74768_a("state", state.ordinal());
        pipeline.func_74768_a("totalPrintTime", totalPrintTime);
        pipeline.func_74768_a("remainingPrintTime", remainingPrintTime);
        sync();
    }

    public void addToQueue(IPrint print)
    {
        printQueue.offer(print);
    }

    private void print(IPrint print)
    {
        field_145850_b.func_184133_a(null, field_174879_c, DeviceSounds.PRINTER_LOADING_PAPER, SoundCategory.BLOCKS, 0.5F, 1.0F);

        setState(LOADING_PAPER);
        currentPrint = print;
        paperCount--;

        pipeline.func_74768_a("paperCount", paperCount);
        pipeline.func_74782_a("currentPrint", IPrint.writeToTag(currentPrint));
        sync();
    }

    public boolean isLoading()
    {
        return state == LOADING_PAPER;
    }

    public boolean isPrinting()
    {
        return state == PRINTING;
    }

    public int getTotalPrintTime()
    {
        return totalPrintTime;
    }

    public int getRemainingPrintTime()
    {
        return remainingPrintTime;
    }

    public boolean addPaper(ItemStack stack, boolean addAll)
    {
        if(!stack.func_190926_b() && stack.func_77973_b() == Items.field_151121_aF && paperCount < DeviceConfig.getMaxPaperCount())
        {
            if(!addAll)
            {
                paperCount++;
                stack.func_190918_g(1);
            }
            else
            {
                paperCount += stack.func_190916_E();
                stack.func_190920_e(Math.max(0, paperCount - 64));
                paperCount = Math.min(64, paperCount);
            }
            pipeline.func_74768_a("paperCount", paperCount);
            sync();
            field_145850_b.func_184133_a(null, field_174879_c, SoundEvents.field_187623_cM, SoundCategory.BLOCKS, 1.0F, 1.0F);
            return true;
        }
        return false;
    }

    public boolean hasPaper()
    {
        return paperCount > 0;
    }

    public int getPaperCount()
    {
        return paperCount;
    }

    public IPrint getPrint()
    {
        return currentPrint;
    }

    public enum State
    {
        LOADING_PAPER(30), PRINTING(0), IDLE(0);

        final int animationTime;

        State(int time)
        {
            this.animationTime = time;
        }

        public State next()
        {
            if(ordinal() + 1 >= values().length)
                return null;
            return values()[ordinal() + 1];
        }
    }
}
