package com.mrcrayfish.device.tileentity;

import com.mrcrayfish.device.util.IColored;
import net.minecraft.item.EnumDyeColor;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.ITickable;
import net.minecraft.util.text.ITextComponent;
import net.minecraft.util.text.TextComponentString;
import net.minecraftforge.common.util.Constants;
import org.apache.commons.lang3.StringUtils;

import javax.annotation.Nullable;
import java.util.UUID;

/**
 * Author: MrCrayfish
 */
public abstract class TileEntityDevice extends TileEntitySync implements ITickable
{
    private EnumDyeColor color = EnumDyeColor.RED;
    private UUID deviceId;
    private String name;

    public final UUID getId()
    {
        if(deviceId == null)
        {
            deviceId = UUID.randomUUID();
        }
        return deviceId;
    }

    public abstract String getDeviceName();

    public String getCustomName()
    {
        return hasCustomName() ? name : getDeviceName();
    }

    public void setCustomName(String name)
    {
       this.name = name;
    }

    public boolean hasCustomName()
    {
        return !StringUtils.isEmpty(name);
    }

    @Nullable
    @Override
    public ITextComponent func_145748_c_()
    {
        return new TextComponentString(getCustomName());
    }

    @Override
    public NBTTagCompound func_189515_b(NBTTagCompound compound)
    {
        super.func_189515_b(compound);
        compound.func_74778_a("deviceId", getId().toString());
        if(hasCustomName())
        {
            compound.func_74778_a("name", name);
        }
        compound.func_74774_a("color", (byte) color.func_176765_a());
        return compound;
    }

    @Override
    public void func_145839_a(NBTTagCompound compound)
    {
        super.func_145839_a(compound);
        if(compound.func_150297_b("deviceId", Constants.NBT.TAG_STRING))
        {
            deviceId = UUID.fromString(compound.func_74779_i("deviceId"));
        }
        if(compound.func_150297_b("name", Constants.NBT.TAG_STRING))
        {
            name = compound.func_74779_i("name");
        }
        if(compound.func_150297_b("color", Constants.NBT.TAG_BYTE))
        {
            this.color = EnumDyeColor.func_176764_b(compound.func_74771_c("color"));
        }
    }

    @Override
    public NBTTagCompound writeSyncTag()
    {
        NBTTagCompound tag = new NBTTagCompound();
        if(hasCustomName())
        {
            tag.func_74778_a("name", name);
        }
        tag.func_74774_a("color", (byte) color.func_176765_a());
        return tag;
    }

    public static abstract class Colored extends TileEntityDevice implements IColored
    {
        private EnumDyeColor color = EnumDyeColor.RED;

        @Override
        public void func_145839_a(NBTTagCompound compound)
        {
            super.func_145839_a(compound);
            if(compound.func_150297_b("color", Constants.NBT.TAG_BYTE))
            {
                this.color = EnumDyeColor.func_176764_b(compound.func_74771_c("color"));
            }
        }

        @Override
        public NBTTagCompound func_189515_b(NBTTagCompound compound)
        {
            super.func_189515_b(compound);
            compound.func_74774_a("color", (byte) color.func_176765_a());
            return compound;
        }

        @Override
        public NBTTagCompound writeSyncTag()
        {
            NBTTagCompound tag = super.writeSyncTag();
            tag.func_74774_a("color", (byte) color.func_176765_a());
            return tag;
        }

        @Override
        public final void setColor(EnumDyeColor color)
        {
            this.color = color;
        }

        @Override
        public final EnumDyeColor getColor()
        {
            return color;
        }
    }
}
