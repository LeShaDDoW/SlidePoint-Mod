package com.mrcrayfish.device.tileentity;

import com.mrcrayfish.device.DeviceConfig;
import com.mrcrayfish.device.core.network.Connection;
import com.mrcrayfish.device.core.network.Router;
import com.mrcrayfish.device.util.IColored;
import net.minecraft.item.EnumDyeColor;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.ITickable;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.text.ITextComponent;
import net.minecraft.util.text.TextComponentString;
import net.minecraftforge.common.util.Constants;

import javax.annotation.Nullable;

/**
 * Author: MrCrayfish
 */
public abstract class TileEntityNetworkDevice extends TileEntityDevice implements ITickable
{
    private int counter;
    private Connection connection;

    @Override
    public void func_73660_a()
    {
        if(field_145850_b.field_72995_K)
            return;

        if(connection != null)
        {
            if(++counter >= DeviceConfig.getBeaconInterval() * 2)
            {
                connection.setRouterPos(null);
                counter = 0;
            }
        }
    }

    public void connect(Router router)
    {
        if(router == null)
        {
            if(connection != null)
            {
                Router connectedRouter = connection.getRouter(field_145850_b);
                if(connectedRouter != null)
                {
                    connectedRouter.removeDevice(this);
                }
            }
            connection = null;
            return;
        }
        connection = new Connection(router);
        counter = 0;
        this.func_70296_d();
    }

    public Connection getConnection()
    {
        return connection;
    }

    @Nullable
    public Router getRouter()
    {
        return connection != null ? connection.getRouter(field_145850_b) : null;
    }

    public boolean isConnected()
    {
        return connection != null && connection.isConnected();
    }

    public boolean receiveBeacon(Router router)
    {
        if(counter >= DeviceConfig.getBeaconInterval() * 2)
        {
            connect(router);
            return true;
        }
        if(connection != null && connection.getRouterId().equals(router.getId()))
        {
            connection.setRouterPos(router.getPos());
            counter = 0;
            return true;
        }
        return false;
    }

    public int getSignalStrength()
    {
        BlockPos routerPos = connection.getRouterPos();
        if(routerPos != null)
        {
            double distance = Math.sqrt(field_174879_c.func_177957_d(routerPos.func_177958_n() + 0.5, routerPos.func_177956_o() + 0.5, routerPos.func_177952_p() + 0.5));
            double level = DeviceConfig.getSignalRange() / 3.0;
            return distance > level * 2 ? 2 : distance > level ? 1 : 0;
        }
        return -1;
    }

    @Nullable
    @Override
    public ITextComponent func_145748_c_()
    {
        return new TextComponentString(getCustomName());
    }

    @Override
    public NBTTagCompound func_189515_b(NBTTagCompound compound)
    {
        super.func_189515_b(compound);
        if(connection != null)
        {
            compound.func_74782_a("connection", connection.toTag());
        }
        return compound;
    }

    @Override
    public void func_145839_a(NBTTagCompound compound)
    {
        super.func_145839_a(compound);
        if(compound.func_150297_b("connection", Constants.NBT.TAG_COMPOUND))
        {
            connection = Connection.fromTag(this, compound.func_74775_l("connection"));
        }
    }

    public static abstract class Colored extends TileEntityNetworkDevice implements IColored
    {
        private EnumDyeColor color = EnumDyeColor.RED;

        @Override
        public void func_145839_a(NBTTagCompound compound)
        {
            super.func_145839_a(compound);
            if(compound.func_150297_b("color", Constants.NBT.TAG_BYTE))
            {
                this.color = EnumDyeColor.func_176764_b(compound.func_74771_c("color"));
            }
        }

        @Override
        public NBTTagCompound func_189515_b(NBTTagCompound compound)
        {
            super.func_189515_b(compound);
            compound.func_74774_a("color", (byte) color.func_176765_a());
            return compound;
        }

        @Override
        public NBTTagCompound writeSyncTag()
        {
            NBTTagCompound tag = super.writeSyncTag();
            tag.func_74774_a("color", (byte) color.func_176765_a());
            return tag;
        }

        @Override
        public final void setColor(EnumDyeColor color)
        {
            this.color = color;
        }

        @Override
        public final EnumDyeColor getColor()
        {
            return color;
        }
    }
}
