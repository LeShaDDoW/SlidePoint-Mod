package com.mrcrayfish.device.tileentity;

import com.mrcrayfish.device.core.network.Router;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraftforge.common.util.Constants;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

/**
 * Author: MrCrayfish
 */
public class TileEntityRouter extends TileEntityDevice.Colored
{
    private Router router;

    @SideOnly(Side.CLIENT)
    private int debugTimer;

    public Router getRouter()
    {
        if(router == null)
        {
            router = new Router(field_174879_c);
            func_70296_d();
        }
        return router;
    }

    public void func_73660_a()
    {
        if(!field_145850_b.field_72995_K)
        {
            getRouter().update(field_145850_b);
        }
        else if(debugTimer > 0)
        {
            debugTimer--;
        }
    }

    @SideOnly(Side.CLIENT)
    public boolean isDebug()
    {
        return debugTimer > 0;
    }

    @SideOnly(Side.CLIENT)
    public void setDebug()
    {
        if(debugTimer <= 0)
        {
            debugTimer = 1200;
        }
        else
        {
            debugTimer = 0;
        }
    }

    @Override
    public String getDeviceName()
    {
        return "Router";
    }

    @Override
    public NBTTagCompound func_189515_b(NBTTagCompound compound)
    {
        super.func_189515_b(compound);
        compound.func_74782_a("router", getRouter().toTag(false));
        return compound;
    }

    @Override
    public void func_145839_a(NBTTagCompound compound)
    {
        super.func_145839_a(compound);
        if(compound.func_150297_b("router", Constants.NBT.TAG_COMPOUND))
        {
            router = Router.fromTag(field_174879_c, compound.func_74775_l("router"));
        }
    }

    public void syncDevicesToClient()
    {
        pipeline.func_74782_a("router", getRouter().toTag(true));
        sync();
    }

    @Override
    public double func_145833_n()
    {
        return 16384;
    }

    @Override
    @SideOnly(Side.CLIENT)
    public AxisAlignedBB getRenderBoundingBox()
    {
        return INFINITE_EXTENT_AABB;
    }
}
