package com.mrcrayfish.device.tileentity;

import com.mrcrayfish.device.api.print.IPrint;
import net.minecraft.init.SoundEvents;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.SoundEvent;
import net.minecraftforge.common.util.Constants;

import javax.annotation.Nullable;

/**
 * Author: MrCrayfish
 */
public class TileEntityPaper extends TileEntitySync
{
    private IPrint print;
    private byte rotation;

    public void nextRotation()
    {
        rotation++;
        if(rotation > 7)
        {
            rotation = 0;
        }
        pipeline.func_74774_a("rotation", rotation);
        sync();
        playSound(SoundEvents.field_187632_cP);
    }

    public float getRotation()
    {
        return rotation * 45F;
    }

    @Nullable
    public IPrint getPrint()
    {
        return print;
    }

    @Override
    public void func_145839_a(NBTTagCompound compound)
    {
        super.func_145839_a(compound);
        if(compound.func_150297_b("print", Constants.NBT.TAG_COMPOUND))
        {
            print = IPrint.loadFromTag(compound.func_74775_l("print"));
        }
        if(compound.func_150297_b("rotation", Constants.NBT.TAG_BYTE))
        {
            rotation = compound.func_74771_c("rotation");
        }
    }

    @Override
    public NBTTagCompound func_189515_b(NBTTagCompound compound)
    {
        super.func_189515_b(compound);
        if(print != null)
        {
            compound.func_74782_a("print", IPrint.writeToTag(print));
        }
        compound.func_74774_a("rotation", rotation);
        return compound;
    }

    @Override
    public NBTTagCompound writeSyncTag()
    {
        NBTTagCompound tag = new NBTTagCompound();
        if(print != null)
        {
            tag.func_74782_a("print", IPrint.writeToTag(print));
        }
        tag.func_74774_a("rotation", rotation);
        return tag;
    }

    private void playSound(SoundEvent sound)
    {
        field_145850_b.func_184133_a(null, field_174879_c, sound, SoundCategory.BLOCKS, 1.0F, 1.0F);
    }
}
