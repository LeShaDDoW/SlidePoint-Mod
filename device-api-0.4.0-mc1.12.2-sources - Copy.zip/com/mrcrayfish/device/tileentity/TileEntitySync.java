package com.mrcrayfish.device.tileentity;

import com.mrcrayfish.device.util.TileEntityUtil;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.network.NetworkManager;
import net.minecraft.network.play.server.SPacketUpdateTileEntity;
import net.minecraft.tileentity.TileEntity;

/**
 * Author: MrCrayfish
 */
public abstract class TileEntitySync extends TileEntity
{
    protected NBTTagCompound pipeline = new NBTTagCompound();

    public void sync()
    {
        TileEntityUtil.markBlockForUpdate(field_145850_b, field_174879_c);
        func_70296_d();
    }

    @Override
    public void onDataPacket(NetworkManager net, SPacketUpdateTileEntity pkt)
    {
        this.func_145839_a(pkt.func_148857_g());
    }

    @Override
    public final NBTTagCompound func_189517_E_()
    {
        if(!pipeline.func_82582_d())
        {
            NBTTagCompound updateTag = super.func_189515_b(pipeline);
            pipeline = new NBTTagCompound();
            return updateTag;
        }
        return super.func_189515_b(writeSyncTag());
    }

    public abstract NBTTagCompound writeSyncTag();

    @Override
    public SPacketUpdateTileEntity func_189518_D_()
    {
        return new SPacketUpdateTileEntity(field_174879_c, 0, func_189517_E_());
    }

    public NBTTagCompound getPipeline()
    {
        return pipeline;
    }
}
