package com.mrcrayfish.device.tileentity;

import com.mrcrayfish.device.entity.EntitySeat;
import com.mrcrayfish.device.util.IColored;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.item.EnumDyeColor;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraftforge.common.util.Constants;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

import java.util.List;

/**
 * Author: MrCrayfish
 */
public class TileEntityOfficeChair extends TileEntitySync implements IColored
{
    private EnumDyeColor color = EnumDyeColor.RED;

    @Override
    public EnumDyeColor getColor()
    {
        return color;
    }

    @Override
    public void setColor(EnumDyeColor color)
    {
        this.color = color;
    }

    @Override
    public void func_145839_a(NBTTagCompound compound)
    {
        super.func_145839_a(compound);
        if(compound.func_150297_b("color", Constants.NBT.TAG_BYTE))
        {
            color = EnumDyeColor.func_176764_b(compound.func_74771_c("color"));
        }
    }

    @Override
    public NBTTagCompound func_189515_b(NBTTagCompound compound)
    {
        super.func_189515_b(compound);
        compound.func_74774_a("color", (byte) color.func_176765_a());
        return compound;
    }

    @Override
    public NBTTagCompound writeSyncTag()
    {
        NBTTagCompound tag = new NBTTagCompound();
        tag.func_74774_a("color", (byte) color.func_176765_a());
        return tag;
    }

    @SideOnly(Side.CLIENT)
    public float getRotation()
    {
        List<EntitySeat> seats = field_145850_b.func_72872_a(EntitySeat.class, new AxisAlignedBB(field_174879_c));
        if(!seats.isEmpty())
        {
            EntitySeat seat = seats.get(0);
            if(seat.func_184179_bs() != null)
            {
                if(seat.func_184179_bs() instanceof EntityLivingBase)
                {
                    EntityLivingBase living = (EntityLivingBase) seat.func_184179_bs();
                    living.field_70761_aq = living.field_70177_z;
                    living.field_70760_ar = living.field_70177_z;
                    return living.field_70177_z;
                }
                return seat.func_184179_bs().field_70177_z;
            }
        }
        return func_145832_p() * 90F + 180F;
    }
}
