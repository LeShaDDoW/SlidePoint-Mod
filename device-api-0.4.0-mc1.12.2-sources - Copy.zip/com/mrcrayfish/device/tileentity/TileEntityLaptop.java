package com.mrcrayfish.device.tileentity;

import com.mrcrayfish.device.core.io.FileSystem;
import com.mrcrayfish.device.util.TileEntityUtil;
import net.minecraft.item.EnumDyeColor;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.nbt.NBTTagList;
import net.minecraft.nbt.NBTTagString;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraftforge.common.util.Constants;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

public class TileEntityLaptop extends TileEntityNetworkDevice.Colored
{
	private static final int OPENED_ANGLE = 102;

	private boolean open = false;

	private NBTTagCompound applicationData;
	private NBTTagCompound systemData;
	private FileSystem fileSystem;

	@SideOnly(Side.CLIENT)
	private int rotation;

	@SideOnly(Side.CLIENT)
	private int prevRotation;

	@SideOnly(Side.CLIENT)
	private EnumDyeColor externalDriveColor;

	@Override
	public String getDeviceName()
	{
		return "Laptop";
	}

	@Override
	public void func_73660_a() 
	{
		super.func_73660_a();
		if(field_145850_b.field_72995_K)
		{
			prevRotation = rotation;
			if(!open)
			{
				if(rotation > 0)
				{
					rotation -= 10F;
				}
			}
			else
			{
				if(rotation < OPENED_ANGLE)
				{
					rotation += 10F;
				}
			}
		}
	}
	
	@Override
	public void func_145839_a(NBTTagCompound compound) 
	{
		super.func_145839_a(compound);
		if(compound.func_74764_b("open"))
		{
			this.open = compound.func_74767_n("open");
		}
		if(compound.func_150297_b("system_data", Constants.NBT.TAG_COMPOUND))
		{
			this.systemData = compound.func_74775_l("system_data");
		}
		if(compound.func_150297_b("application_data", Constants.NBT.TAG_COMPOUND))
		{
			this.applicationData = compound.func_74775_l("application_data");
		}
		if(compound.func_74764_b("file_system"))
		{
			this.fileSystem = new FileSystem(this, compound.func_74775_l("file_system"));
		}
		if(compound.func_150297_b("external_drive_color", Constants.NBT.TAG_BYTE))
		{
			this.externalDriveColor = null;
			if(compound.func_74771_c("external_drive_color") != -1)
			{
				this.externalDriveColor = EnumDyeColor.func_176764_b(compound.func_74771_c("external_drive_color"));
			}
		}
	}
	
	@Override
	public NBTTagCompound func_189515_b(NBTTagCompound compound) 
	{
		super.func_189515_b(compound);
		compound.func_74757_a("open", open);

		if(systemData != null)
		{
			compound.func_74782_a("system_data", systemData);
		}

		if(applicationData != null)
		{
			compound.func_74782_a("application_data", applicationData);
		}

		if(fileSystem != null)
		{
			compound.func_74782_a("file_system", fileSystem.toTag());
		}
		return compound;
	}

	@Override
	public NBTTagCompound writeSyncTag()
	{
		NBTTagCompound tag = super.writeSyncTag();
		tag.func_74757_a("open", open);
		tag.func_74782_a("system_data", getSystemData());

		if(getFileSystem().getAttachedDrive() != null)
		{
			tag.func_74774_a("external_drive_color", (byte) getFileSystem().getAttachedDriveColor().func_176765_a());
		}
		else
		{
			tag.func_74774_a("external_drive_color", (byte) -1);
		}

		return tag;
	}

	@Override
	public double func_145833_n() 
	{
		return 16384;
	}

	@Override
	@SideOnly(Side.CLIENT)
	public AxisAlignedBB getRenderBoundingBox() 
	{
		return INFINITE_EXTENT_AABB;
	}

	public void openClose()
	{
		open = !open;
		pipeline.func_74757_a("open", open);
		sync();
	}

	public boolean isOpen()
	{
		return open;
	}

	public NBTTagCompound getApplicationData()
    {
		return applicationData != null ? applicationData : new NBTTagCompound();
    }

	public NBTTagCompound getSystemData()
	{
		if(systemData == null)
		{
			systemData = new NBTTagCompound();
		}
		return systemData;
	}

	public FileSystem getFileSystem()
	{
		if(fileSystem == null)
		{
			fileSystem = new FileSystem(this, new NBTTagCompound());
		}
		return fileSystem;
	}

	public void setApplicationData(String appId, NBTTagCompound applicationData)
	{
		this.applicationData = applicationData;
		func_70296_d();
		TileEntityUtil.markBlockForUpdate(field_145850_b, field_174879_c);
	}

	public void setSystemData(NBTTagCompound systemData)
	{
		this.systemData = systemData;
		func_70296_d();
		TileEntityUtil.markBlockForUpdate(field_145850_b, field_174879_c);
	}

	@SideOnly(Side.CLIENT)
	public float getScreenAngle(float partialTicks)
	{
		return -OPENED_ANGLE * ((prevRotation + (rotation - prevRotation) * partialTicks) / OPENED_ANGLE);
	}

	@SideOnly(Side.CLIENT)
	public boolean isExternalDriveAttached()
	{
		return externalDriveColor != null;
	}

	@SideOnly(Side.CLIENT)
	public EnumDyeColor getExternalDriveColor()
	{
		return externalDriveColor;
	}
}
