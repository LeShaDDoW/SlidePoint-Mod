package com.mrcrayfish.device.entity;

import net.minecraft.entity.Entity;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

import javax.annotation.Nullable;
import java.util.List;

/**
 * Author: MrCrayfish
 */
public class EntitySeat extends Entity
{
    public EntitySeat(World worldIn)
    {
        super(worldIn);
        this.func_70105_a(0.001F, 0.001F);
        this.func_82142_c(true);
    }

    public EntitySeat(World worldIn, BlockPos pos, double yOffset)
    {
        this(worldIn);
        this.func_70107_b(pos.func_177958_n() + 0.5, pos.func_177956_o() + yOffset, pos.func_177952_p() + 0.5);
    }

    @Override
    protected boolean func_142008_O()
    {
        return false;
    }

    @Override
    public void func_70030_z()
    {
        if(!this.field_70170_p.field_72995_K && (!this.func_184207_aI() || this.field_70170_p.func_175623_d(new BlockPos(this.field_70165_t, this.field_70163_u, this.field_70161_v))))
        {
            this.func_70106_y();
        }
    }

    @Nullable
    public Entity func_184179_bs()
    {
        List<Entity> list = this.func_184188_bt();
        return list.isEmpty() ? null : list.get(0);
    }

    @Override
    protected void func_70088_a() {}

    @Override
    protected void func_70037_a(NBTTagCompound compound) {}

    @Override
    protected void func_70014_b(NBTTagCompound compound) {}
}
