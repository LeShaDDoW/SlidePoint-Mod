package com.mrcrayfish.device.programs.auction.object;

import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;

import java.util.UUID;

public class AuctionItem
{
	private UUID id;
	private ItemStack stack;
	private int price;
	private long timeLeft;
	private UUID sellerId;
	
	public AuctionItem(ItemStack stack, int price, long timeLeft, UUID sellerId)
	{
		this.id = UUID.randomUUID();
		this.stack = stack;
		this.price = price;
		this.timeLeft = timeLeft;
		this.sellerId = sellerId;
	}
	
	public AuctionItem(UUID id, ItemStack stack, int price, long timeLeft, UUID sellerId)
	{
		this.id = id;
		this.stack = stack;
		this.price = price;
		this.timeLeft = timeLeft;
		this.sellerId = sellerId;
	}
	
	public UUID getId()
	{
		return id;
	}

	public ItemStack getStack()
	{
		return stack;
	}

	public int getPrice()
	{
		return price;
	}
	
	public UUID getSellerId()
	{
		return sellerId;
	}
	
	public boolean isValid()
	{
		return timeLeft > 0;
	}
	
	public void decrementTime() 
	{
		if(timeLeft > 0)
		{
			timeLeft--;
		}
	}
	
	public long getTimeLeft()
	{
		return timeLeft;
	}
	
	public void setSold()
	{
		this.timeLeft = 0;
	}
	
	public void writeToNBT(NBTTagCompound tag)
	{
		tag.func_74778_a("id", id.toString());
		NBTTagCompound item = new NBTTagCompound();
		stack.func_77955_b(item);
		tag.func_74782_a("item", item);
		tag.func_74768_a("price", price);
		tag.func_74772_a("time", timeLeft);
		tag.func_74778_a("seller", sellerId.toString());
	}
	
	public static AuctionItem readFromNBT(NBTTagCompound tag)
	{
		UUID id = UUID.fromString(tag.func_74779_i("id"));
		NBTTagCompound item = tag.func_74775_l("item");
		ItemStack stack = new ItemStack(item);
		int price = tag.func_74762_e("price");
		long timeLeft = tag.func_74763_f("time");
		UUID sellerId = UUID.fromString(tag.func_74779_i("seller"));
		return new AuctionItem(id, stack, price, timeLeft, sellerId);
	}
	
	@Override
	public String toString()
	{
		return "{ " + id + ", " + stack + ", " + price + ", " + timeLeft + ", " + sellerId + " }"; 
	}
}
