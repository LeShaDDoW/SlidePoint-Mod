package com.mrcrayfish.device.programs.auction.task;

import com.mrcrayfish.device.api.task.Task;
import com.mrcrayfish.device.programs.auction.AuctionManager;
import com.mrcrayfish.device.programs.auction.object.AuctionItem;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.world.World;

public class TaskAddAuction extends Task
{
	private int slot;
	private int amount;
	private int price;
	private int duration;
	
	private AuctionItem item;
	
	public TaskAddAuction()
	{
		super("minebay_add_auction");
	}
	
	public TaskAddAuction(int slot, int amount, int price, int duration)
	{
		this();
		this.slot = slot;
		this.amount = amount;
		this.price = price;
		this.duration = duration;
	}

	@Override
	public void prepareRequest(NBTTagCompound nbt) 
	{
		nbt.func_74768_a("slot", slot);
		nbt.func_74768_a("amount", amount);
		nbt.func_74768_a("price", price);
		nbt.func_74768_a("duration", duration);
	}

	@Override
	public void processRequest(NBTTagCompound nbt, World world, EntityPlayer player) 
	{
		int slot = nbt.func_74762_e("slot");
		int amount = nbt.func_74762_e("amount");
		int price = nbt.func_74762_e("price");
		int duration = nbt.func_74762_e("duration");
		
		if(slot >= 0 && price >= 0 && slot < player.field_71071_by.func_70302_i_())
		{
			ItemStack real = player.field_71071_by.func_70301_a(slot);
			if(real != null)
			{
				ItemStack stack = real.func_77946_l();
				stack.func_190920_e(amount);
				real.func_190918_g(amount);
				//TODO Test this
				
				item = new AuctionItem(stack, price, duration, player.func_110124_au());
				
				AuctionManager.INSTANCE.addItem(item);
				
				this.setSuccessful();
			}
		}
	}

	@Override
	public void prepareResponse(NBTTagCompound nbt)
	{
		if(isSucessful())
		{
			item.writeToNBT(nbt);
		}
	}

	@Override
	public void processResponse(NBTTagCompound nbt) 
	{
		if(isSucessful())
		{
			AuctionManager.INSTANCE.addItem(AuctionItem.readFromNBT(nbt));
		}
	}
}
