package com.mrcrayfish.device.programs.email;

import com.google.common.collect.HashBiMap;
import com.mrcrayfish.device.api.app.Icons;
import com.mrcrayfish.device.api.app.Notification;
import com.mrcrayfish.device.programs.email.object.Email;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.nbt.NBTTagList;
import net.minecraft.server.MinecraftServer;
import net.minecraftforge.fml.common.FMLCommonHandler;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

import java.util.*;

/**
 * Author: MrCrayfish
 */
public class EmailManager
{
    public static final EmailManager INSTANCE = new EmailManager();

    @SideOnly(Side.CLIENT)
    private List<Email> inbox;

    private HashBiMap<UUID, String> uuidToName = HashBiMap.create();
    private Map<String, List<Email>> nameToInbox = new HashMap<>();

    public boolean addEmailToInbox(Email email, String to)
    {
        if (nameToInbox.containsKey(to))
        {
            nameToInbox.get(to).add(0, email);
            sendNotification(to, email);
            return true;
        }
        return false;
    }

    @SideOnly(Side.CLIENT)
    public List<Email> getInbox()
    {
        if(inbox == null)
        {
            inbox = new ArrayList<>();
        }
        return inbox;
    }

    public List<Email> getEmailsForAccount(EntityPlayer player)
    {
        if (uuidToName.containsKey(player.func_110124_au()))
        {
            return nameToInbox.get(uuidToName.get(player.func_110124_au()));
        }
        return new ArrayList<Email>();
    }

    public boolean addAccount(EntityPlayer player, String name)
    {
        if (!uuidToName.containsKey(player.func_110124_au()))
        {
            if (!uuidToName.containsValue(name))
            {
                uuidToName.put(player.func_110124_au(), name);
                nameToInbox.put(name, new ArrayList<Email>());
                return true;
            }
        }
        return false;
    }

    public boolean hasAccount(UUID uuid)
    {
        return uuidToName.containsKey(uuid);
    }

    public String getName(EntityPlayer player)
    {
        return uuidToName.get(player.func_110124_au());
    }

    public void readFromNBT(NBTTagCompound nbt)
    {
        nameToInbox.clear();

        NBTTagList inboxes = (NBTTagList) nbt.func_74781_a("Inboxes");
        for (int i = 0; i < inboxes.func_74745_c(); i++)
        {
            NBTTagCompound inbox = inboxes.func_150305_b(i);
            String name = inbox.func_74779_i("Name");

            List<Email> emails = new ArrayList<Email>();
            NBTTagList emailTagList = (NBTTagList) inbox.func_74781_a("Emails");
            for (int j = 0; j < emailTagList.func_74745_c(); j++)
            {
                NBTTagCompound emailTag = emailTagList.func_150305_b(j);
                Email email = Email.readFromNBT(emailTag);
                emails.add(email);
            }
            nameToInbox.put(name, emails);
        }

        uuidToName.clear();

        NBTTagList accounts = (NBTTagList) nbt.func_74781_a("Accounts");
        for (int i = 0; i < accounts.func_74745_c(); i++)
        {
            NBTTagCompound account = accounts.func_150305_b(i);
            UUID uuid = UUID.fromString(account.func_74779_i("UUID"));
            String name = account.func_74779_i("Name");
            uuidToName.put(uuid, name);
        }
    }

    public void writeToNBT(NBTTagCompound nbt)
    {
        NBTTagList inboxes = new NBTTagList();
        for (String key : nameToInbox.keySet())
        {
            NBTTagCompound inbox = new NBTTagCompound();
            inbox.func_74778_a("Name", key);

            NBTTagList emailTagList = new NBTTagList();
            List<Email> emails = nameToInbox.get(key);
            for (Email email : emails)
            {
                NBTTagCompound emailTag = new NBTTagCompound();
                email.writeToNBT(emailTag);
                emailTagList.func_74742_a(emailTag);
            }
            inbox.func_74782_a("Emails", emailTagList);
            inboxes.func_74742_a(inbox);
        }
        nbt.func_74782_a("Inboxes", inboxes);

        NBTTagList accounts = new NBTTagList();
        for (UUID key : uuidToName.keySet())
        {
            NBTTagCompound account = new NBTTagCompound();
            account.func_74778_a("UUID", key.toString());
            account.func_74778_a("Name", uuidToName.get(key));
            accounts.func_74742_a(account);
        }
        nbt.func_74782_a("Accounts", accounts);
    }

    public void clear()
    {
        nameToInbox.clear();
        uuidToName.clear();
        inbox.clear();
    }

    private void sendNotification(String name, Email email)
    {
        MinecraftServer server = FMLCommonHandler.instance().getMinecraftServerInstance();
        UUID id = uuidToName.inverse().get(name);
        if(id != null)
        {
            EntityPlayerMP player = server.func_184103_al().func_177451_a(id);
            if(player != null)
            {
                Notification notification = new Notification(Icons.MAIL, "New Email!", "from " + email.getAuthor());
                notification.pushTo(player);
            }
        }
    }
}
