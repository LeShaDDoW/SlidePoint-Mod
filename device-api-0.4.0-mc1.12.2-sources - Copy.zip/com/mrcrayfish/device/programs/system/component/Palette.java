package com.mrcrayfish.device.programs.system.component;

import com.mrcrayfish.device.api.app.Component;
import com.mrcrayfish.device.api.app.Layout;
import com.mrcrayfish.device.api.app.component.ComboBox;
import com.mrcrayfish.device.api.app.component.Slider;
import com.mrcrayfish.device.core.Laptop;
import com.mrcrayfish.device.util.GLHelper;
import com.mrcrayfish.device.util.GuiHelper;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.renderer.BufferBuilder;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import org.lwjgl.opengl.GL11;

import java.awt.*;

/**
 * Author: MrCrayfish
 */
public class Palette extends Component
{
    private ComboBox.Custom<Integer> colorPicker;

    private Color currentColor = Color.RED;

    private Slider colorSlider;

    /**
     * The default constructor for a component.
     * <p>
     * Laying out components is simply relative positioning. So for left (x position),
     * specific how many pixels from the left of the application window you want
     * it to be positioned at. The top is the same, but instead from the top (y position).
     *
     * @param left how many pixels from the left
     * @param top  how many pixels from the top
     */
    public Palette(int left, int top, ComboBox.Custom<Integer> colorPicker)
    {
        super(left, top);
        this.colorPicker = colorPicker;
    }

    @Override
    protected void init(Layout layout)
    {
        colorSlider = new Slider(5, 58, 52);
        colorSlider.setSlideListener(percentage ->
        {
            if(percentage >= (1.0 / 6.0) * 5.0)
            {
                currentColor = new Color(1.0F, 1.0F - (percentage - (1.0F / 6.0F) * 5.0F) * 6.0F, 0.0F);
            }
            else if(percentage >= (1.0 / 6.0) * 4.0)
            {
                currentColor = new Color((percentage - ((1.0F / 6.0F) * 4.0F)) * 6.0F, 1.0F, 0.0F);
            }
            else if(percentage >= (1.0 / 6.0) * 3.0)
            {
                currentColor = new Color(0.0F, 1.0F, 1.0F - (percentage - ((1.0F / 6.0F) * 3.0F)) * 6.0F);
            }
            else if(percentage >= (1.0 / 6.0) * 2.0)
            {
                currentColor = new Color(0.0F, (percentage - ((1.0F / 6.0F) * 2.0F)) * 6.0F, 1.0F);
            }
            else if(percentage >= (1.0 / 6.0) * 1.0)
            {
                currentColor = new Color(1.0F - (percentage - ((1.0F / 6.0F) * 1.0F)) * 6.0F, 0.0F, 1.0F);
            }
            else if(percentage >= (1.0 / 6.0) * 0.0)
            {
                currentColor = new Color(1.0F, 0.0F, percentage * 6.0F);
            }
        });
        layout.addComponent(colorSlider);
    }

    @Override
    protected void render(Laptop laptop, Minecraft mc, int x, int y, int mouseX, int mouseY, boolean windowActive, float partialTicks)
    {
        Gui.func_73734_a(x, y, x + 52, y + 52, Color.DARK_GRAY.getRGB());

        GlStateManager.func_179140_f();
        GlStateManager.func_179090_x();
        GlStateManager.func_179147_l();
        GlStateManager.func_179118_c();
        GlStateManager.func_187428_a(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA, GlStateManager.SourceFactor.ONE, GlStateManager.DestFactor.ZERO);
        GlStateManager.func_179103_j(GL11.GL_SMOOTH);

        Tessellator tessellator = Tessellator.func_178181_a();
        BufferBuilder buffer = tessellator.func_178180_c();
        buffer.func_181668_a(7, DefaultVertexFormats.field_181706_f);
        buffer.func_181662_b((double) x + 1, (double)(y + 1 + 50), 1).func_181666_a(0.0F, 0.0F, 0.0F, 1.0F).func_181675_d();
        buffer.func_181662_b((double)(x + 1 + 50), (double)(y + 1 + 50), 1).func_181666_a(0.0F, 0.0F, 0.0F, 1.0F).func_181675_d();
        buffer.func_181662_b((double)(x + 1 + 50), (double) y + 1, 1).func_181666_a(currentColor.getRed() / 255F, currentColor.getGreen() / 255F, currentColor.getBlue() / 255F, 1.0F).func_181675_d();
        buffer.func_181662_b((double) x + 1, (double) y + 1, 1).func_181666_a(1.0F, 1.0F, 1.0F, 1.0F).func_181675_d();
        tessellator.func_78381_a();

        GlStateManager.func_179103_j(GL11.GL_FLAT);
        GlStateManager.func_179084_k();
        GlStateManager.func_179141_d();
        GlStateManager.func_179098_w();
    }

    @Override
    protected void handleMouseClick(int mouseX, int mouseY, int mouseButton)
    {
        if(mouseButton != 0)
            return;

        if(GuiHelper.isMouseInside(mouseX, mouseY, xPosition + 1, yPosition + 1, xPosition + 51, yPosition + 51))
        {
            colorPicker.setValue(GLHelper.getPixel(mouseX, mouseY).getRGB());
        }
    }
}
