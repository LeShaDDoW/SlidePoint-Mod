package com.mrcrayfish.device.programs.system.task;

import com.mrcrayfish.device.api.task.Task;
import com.mrcrayfish.device.tileentity.TileEntityLaptop;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

public class TaskUpdateSystemData extends Task
{
    private BlockPos pos;
    private NBTTagCompound data;

    public TaskUpdateSystemData()
    {
        super("update_system_data");
    }

    public TaskUpdateSystemData(BlockPos pos, NBTTagCompound data)
    {
        this();
        this.pos = pos;
        this.data = data;
    }

    @Override
    public void prepareRequest(NBTTagCompound tag)
    {
        tag.func_74772_a("pos", pos.func_177986_g());
        tag.func_74782_a("data", this.data);
    }

    @Override
    public void processRequest(NBTTagCompound tag, World world, EntityPlayer player)
    {
        BlockPos pos = BlockPos.func_177969_a(tag.func_74763_f("pos"));
        TileEntity tileEntity = world.func_175625_s(pos);
        if(tileEntity instanceof TileEntityLaptop)
        {
            TileEntityLaptop laptop = (TileEntityLaptop) tileEntity;
            laptop.setSystemData(tag.func_74775_l("data"));
        }
        this.setSuccessful();
    }

    @Override
    public void prepareResponse(NBTTagCompound tag)
    {

    }

    @Override
    public void processResponse(NBTTagCompound tag)
    {

    }
}
