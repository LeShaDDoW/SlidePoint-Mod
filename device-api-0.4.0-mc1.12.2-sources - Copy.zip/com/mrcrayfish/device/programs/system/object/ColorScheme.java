package com.mrcrayfish.device.programs.system.object;

import net.minecraft.nbt.NBTTagCompound;
import net.minecraftforge.common.util.Constants;

import java.awt.*;

/**
 * Author: MrCrayfish
 */
public class ColorScheme
{
    public int textColor;
    public int textSecondaryColor;
    public int headerColor;
    public int backgroundColor;
    public int backgroundSecondaryColor;
    public int itemBackgroundColor;
    public int itemHighlightColor;

    public ColorScheme()
    {
        resetDefault();
    }

    public int getTextColor()
    {
        return textColor;
    }

    public void setTextColor(int textColor)
    {
        this.textColor = textColor;
    }

    public int getTextSecondaryColor()
    {
        return textSecondaryColor;
    }

    public void setTextSecondaryColor(int textSecondaryColor)
    {
        this.textSecondaryColor = textSecondaryColor;
    }

    public int getHeaderColor()
    {
        return headerColor;
    }

    public void setHeaderColor(int headerColor)
    {
        this.headerColor = headerColor;
    }

    public int getBackgroundColor()
    {
        return backgroundColor;
    }

    public void setBackgroundColor(int backgroundColor)
    {
        this.backgroundColor = backgroundColor;
    }

    public int getBackgroundSecondaryColor()
    {
        return backgroundSecondaryColor;
    }

    public void setBackgroundSecondaryColor(int backgroundSecondaryColor)
    {
        this.backgroundSecondaryColor = backgroundSecondaryColor;
    }

    public int getItemBackgroundColor()
    {
        return itemBackgroundColor;
    }

    public void setItemBackgroundColor(int itemBackgroundColor)
    {
        this.itemBackgroundColor = itemBackgroundColor;
    }

    public int getItemHighlightColor()
    {
        return itemHighlightColor;
    }

    public void setItemHighlightColor(int itemHighlightColor)
    {
        this.itemHighlightColor = itemHighlightColor;
    }

    public void resetDefault()
    {
        textColor = Color.decode("0xFFFFFF").getRGB();
        textSecondaryColor = Color.decode("0x9BEDF2").getRGB();
        headerColor = Color.decode("0x959fa6").getRGB();
        backgroundColor = Color.decode("0x535861").getRGB();
        backgroundSecondaryColor = 0;
        itemBackgroundColor = Color.decode("0x9E9E9E").getRGB();
        itemHighlightColor = Color.decode("0x757575").getRGB();
    }

    public NBTTagCompound toTag()
    {
        NBTTagCompound tag = new NBTTagCompound();
        tag.func_74768_a("textColor", textColor);
        tag.func_74768_a("textSecondaryColor", textSecondaryColor);
        tag.func_74768_a("headerColor", headerColor);
        tag.func_74768_a("backgroundColor", backgroundColor);
        tag.func_74768_a("backgroundSecondaryColor", backgroundSecondaryColor);
        tag.func_74768_a("itemBackgroundColor", itemBackgroundColor);
        tag.func_74768_a("itemHighlightColor", itemHighlightColor);
        return tag;
    }

    public static ColorScheme fromTag(NBTTagCompound tag)
    {
        ColorScheme scheme = new ColorScheme();
        if(tag.func_150297_b("textColor", Constants.NBT.TAG_INT))
        {
            scheme.textColor = tag.func_74762_e("textColor");
        }
        if(tag.func_150297_b("textSecondaryColor", Constants.NBT.TAG_INT))
        {
            scheme.textSecondaryColor = tag.func_74762_e("textSecondaryColor");
        }
        if(tag.func_150297_b("headerColor", Constants.NBT.TAG_INT))
        {
            scheme.headerColor = tag.func_74762_e("headerColor");
        }
        if(tag.func_150297_b("backgroundColor", Constants.NBT.TAG_INT))
        {
            scheme.backgroundColor = tag.func_74762_e("backgroundColor");
        }
        if(tag.func_150297_b("backgroundSecondaryColor", Constants.NBT.TAG_INT))
        {
            scheme.backgroundSecondaryColor = tag.func_74762_e("backgroundSecondaryColor");
        }
        if(tag.func_150297_b("itemBackgroundColor", Constants.NBT.TAG_INT))
        {
            scheme.itemBackgroundColor = tag.func_74762_e("itemBackgroundColor");
        }
        if(tag.func_150297_b("itemHighlightColor", Constants.NBT.TAG_INT))
        {
            scheme.itemHighlightColor = tag.func_74762_e("itemHighlightColor");
        }
        return scheme;
    }
}
