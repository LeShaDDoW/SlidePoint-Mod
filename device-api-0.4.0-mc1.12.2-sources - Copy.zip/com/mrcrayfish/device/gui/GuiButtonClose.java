package com.mrcrayfish.device.gui;

import com.mrcrayfish.device.core.Window;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.renderer.GlStateManager;

public class GuiButtonClose extends GuiButton
{
	public GuiButtonClose(int buttonId, int x, int y) 
	{
		super(buttonId, x, y, 11, 11, "");
	}

	@Override
	public void func_191745_a(Minecraft mc, int mouseX, int mouseY, float partialTicks)
	{
		if (this.field_146125_m)
		{
			FontRenderer fontrenderer = mc.field_71466_p;
			mc.func_110434_K().func_110577_a(Window.WINDOW_GUI);
			GlStateManager.func_179131_c(1.0F, 1.0F, 1.0F, 1.0F);
			this.field_146123_n = mouseX >= this.field_146128_h && mouseY >= this.field_146129_i && mouseX < this.field_146128_h + this.field_146120_f && mouseY < this.field_146129_i + this.field_146121_g;

			GlStateManager.func_179147_l();
			GlStateManager.func_179120_a(770, 771, 1, 0);
			GlStateManager.func_179112_b(770, 771);

			int state = this.func_146114_a(this.field_146123_n);
			this.func_73729_b(this.field_146128_h, this.field_146129_i, state * this.field_146120_f + 15, 0, this.field_146120_f, this.field_146121_g);
		}
	}
}
