package com.mrcrayfish.device.item;

import net.minecraft.block.Block;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;

import javax.annotation.Nullable;

/**
 * Author: MrCrayfish
 */
public class ItemPaper extends ItemBlock
{
    public ItemPaper(Block block)
    {
        super(block);
        this.func_77625_d(1);
    }



    @Nullable
    @Override
    public NBTTagCompound getNBTShareTag(ItemStack stack)
    {
        NBTTagCompound tag = stack.func_77978_p();
        if(tag != null)
        {
            NBTTagCompound copy = tag.func_74737_b();
            copy.func_82580_o("BlockEntityTag");
            return copy;
        }
        return null;
    }
}
