package com.mrcrayfish.device.item;

import com.mrcrayfish.device.MrCrayfishDeviceMod;
import com.mrcrayfish.device.Reference;
import net.minecraft.client.util.ITooltipFlag;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.item.EnumDyeColor;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.NonNullList;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.text.TextFormatting;
import net.minecraft.world.World;
import org.apache.commons.lang3.text.WordUtils;

import javax.annotation.Nullable;
import java.util.List;

/**
 * Author: MrCrayfish
 */
public class ItemFlashDrive extends Item implements SubItems
{
    public ItemFlashDrive()
    {
        this.func_77655_b("flash_drive");
        this.setRegistryName("flash_drive");
        this.func_77637_a(MrCrayfishDeviceMod.TAB_DEVICE);
        this.func_77625_d(1);
        this.func_77656_e(0);
        this.func_77627_a(true);
    }

    @Override
    public void func_77624_a(ItemStack stack, @Nullable World worldIn, List<String> tooltip, ITooltipFlag flagIn)
    {
        EnumDyeColor color = EnumDyeColor.func_176764_b(stack.func_77960_j());
        String colorName = color.func_176610_l().replace("_", " ");
        colorName = WordUtils.capitalize(colorName);
        tooltip.add("Color: " + TextFormatting.BOLD.toString() + getFromColor(color).toString() + colorName);
    }

    @Override
    public void func_150895_a(CreativeTabs tab, NonNullList<ItemStack> items)
    {
        if(func_194125_a(tab))
        {
            for(EnumDyeColor color : EnumDyeColor.values())
            {
                items.add(new ItemStack(this, 1, color.func_176765_a()));
            }
        }
    }

    @Override
    public NonNullList<ResourceLocation> getModels()
    {
        NonNullList<ResourceLocation> modelLocations = NonNullList.func_191196_a();
        for(EnumDyeColor color : EnumDyeColor.values())
        {
            modelLocations.add(new ResourceLocation(Reference.MOD_ID, func_77658_a().substring(5) + "/" + color.func_176610_l()));
        }
        return modelLocations;
    }

    private static TextFormatting getFromColor(EnumDyeColor color)
    {
        switch(color)
        {
            case ORANGE: return TextFormatting.GOLD;
            case MAGENTA: return TextFormatting.LIGHT_PURPLE;
            case LIGHT_BLUE: return TextFormatting.BLUE;
            case YELLOW: return TextFormatting.YELLOW;
            case LIME: return TextFormatting.GREEN;
            case PINK: return TextFormatting.LIGHT_PURPLE;
            case GRAY: return TextFormatting.DARK_GRAY;
            case SILVER: return TextFormatting.GRAY;
            case CYAN: return TextFormatting.DARK_AQUA;
            case PURPLE: return TextFormatting.DARK_PURPLE;
            case BLUE: return TextFormatting.DARK_BLUE;
            case BROWN: return TextFormatting.GOLD;
            case GREEN: return TextFormatting.DARK_GREEN;
            case RED: return TextFormatting.DARK_RED;
            case BLACK: return TextFormatting.BLACK;
            default: return TextFormatting.WHITE;
        }
    }
}
