package com.mrcrayfish.device.item;

import com.mrcrayfish.device.MrCrayfishDeviceMod;
import net.minecraft.item.Item;

/**
 * Author: MrCrayfish
 */
public class ItemComponent extends Item
{
    public ItemComponent(String id)
    {
        this.func_77655_b(id);
        this.setRegistryName(id);
        this.func_77637_a(MrCrayfishDeviceMod.TAB_DEVICE);
    }
}
