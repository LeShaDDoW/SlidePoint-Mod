package com.mrcrayfish.device.item;

import net.minecraft.util.NonNullList;
import net.minecraft.util.ResourceLocation;

/**
 * Author: MrCrayfish
 */
public interface SubItems
{
    NonNullList<ResourceLocation> getModels();
}
