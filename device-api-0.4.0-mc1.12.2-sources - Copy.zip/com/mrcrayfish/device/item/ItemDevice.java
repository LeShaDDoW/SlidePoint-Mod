package com.mrcrayfish.device.item;

import net.minecraft.block.Block;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraftforge.common.util.Constants;

import javax.annotation.Nullable;

/**
 * Author: MrCrayfish
 */
public class ItemDevice extends ItemBlock
{
    public ItemDevice(Block block)
    {
        super(block);
        this.func_77625_d(1);
    }

    //This method is still bugged due to Forge.
    @Nullable
    @Override
    public NBTTagCompound getNBTShareTag(ItemStack stack)
    {
        NBTTagCompound tag = new NBTTagCompound();
        if(stack.func_77978_p() != null && stack.func_77978_p().func_150297_b("display", Constants.NBT.TAG_COMPOUND))
        {
            tag.func_74782_a("display", stack.func_77978_p().func_74781_a("display"));
        }
        return tag;
    }
}
