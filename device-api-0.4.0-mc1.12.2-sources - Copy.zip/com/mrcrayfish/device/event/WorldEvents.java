package com.mrcrayfish.device.event;

import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.text.Style;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.util.text.TextFormatting;
import net.minecraft.util.text.event.ClickEvent;
import net.minecraft.util.text.event.ClickEvent.Action;
import net.minecraft.util.text.event.HoverEvent;
import net.minecraftforge.event.entity.EntityJoinWorldEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class WorldEvents {
	
	public static boolean displayed = false;
	
	@SubscribeEvent
	public void load(EntityJoinWorldEvent event)
	{
		if(!displayed && event.getEntity() instanceof EntityPlayer && event.getWorld().field_72995_K) 
		{
			Style style = new Style();
			style.func_150241_a(new ClickEvent(Action.OPEN_URL, "https://www.patreon.com/mrcrayfish"));
			style.func_150209_a(new HoverEvent(HoverEvent.Action.SHOW_TEXT, new TextComponentString(TextFormatting.AQUA + "Open MrCrayfish's Patreon")));
			event.getEntity().func_145747_a(new TextComponentString(TextFormatting.RED.toString() + TextFormatting.BOLD.toString() + "MrCrayfish's Device Mod:"));
			event.getEntity().func_145747_a(new TextComponentString("You are using a development version of the Device Mod."));
			event.getEntity().func_145747_a(new TextComponentString("Please be aware that not all features are finished"));
			event.getEntity().func_145747_a(new TextComponentString("and may be completely changed in a future update!"));
			event.getEntity().func_145747_a(new TextComponentString(TextFormatting.GOLD.toString() + TextFormatting.BOLD.toString() + "> Support MrCrayfish On Patreon <").func_150255_a(style));
		}
	}
	
}
