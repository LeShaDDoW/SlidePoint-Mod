package com.mrcrayfish.device.api.utils;

import com.mrcrayfish.device.core.Laptop;
import com.mrcrayfish.device.object.AppInfo;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.renderer.BufferBuilder;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.item.ItemStack;
import net.minecraft.util.text.TextFormatting;

import javax.annotation.Nullable;

public class RenderUtil
{
	public static void renderItem(int x, int y, ItemStack stack, boolean overlay)
	{
		GlStateManager.func_179097_i();
		GlStateManager.func_179145_e();
		RenderHelper.func_74520_c();
		Minecraft.func_71410_x().func_175599_af().func_180450_b(stack, x, y);
		if(overlay) Minecraft.func_71410_x().func_175599_af().func_175030_a(Minecraft.func_71410_x().field_71466_p, stack, x, y);
		GlStateManager.func_179141_d();
		GlStateManager.func_179140_f();
	}
	
	public static void drawRectWithTexture(double x, double y, float u, float v, int width, int height, float textureWidth, float textureHeight)
    {
		drawRectWithTexture(x, y, 0, u, v, width, height, textureWidth, textureHeight);
    }
	
	/**
	 * Texture size must be 256x256
	 * 
	 * @param x
	 * @param y
	 * @param z
	 * @param u
	 * @param v
	 * @param width
	 * @param height
	 * @param textureWidth
	 * @param textureHeight
	 */
	public static void drawRectWithTexture(double x, double y, double z, float u, float v, int width, int height, float textureWidth, float textureHeight)
    {
		float scale = 0.00390625F;
        Tessellator tessellator = Tessellator.func_178181_a();
        BufferBuilder buffer = tessellator.func_178180_c();
        buffer.func_181668_a(7, DefaultVertexFormats.field_181707_g);
        buffer.func_181662_b(x, y + height, z).func_187315_a((double)(u * scale), (double)(v + textureHeight) * scale).func_181675_d();
        buffer.func_181662_b(x + width, y + height, z).func_187315_a((double)(u + textureWidth) * scale, (double)(v + textureHeight) * scale).func_181675_d();
        buffer.func_181662_b(x + width, y, z).func_187315_a((double)(u + textureWidth) * scale, (double)(v * scale)).func_181675_d();
        buffer.func_181662_b(x, y, z).func_187315_a((double)(u * scale), (double)(v * scale)).func_181675_d();
        tessellator.func_78381_a();
    }

	public static void drawRectWithFullTexture(double x, double y, float u, float v, int width, int height)
	{
		Tessellator tessellator = Tessellator.func_178181_a();
		BufferBuilder buffer = tessellator.func_178180_c();
		buffer.func_181668_a(7, DefaultVertexFormats.field_181707_g);
		buffer.func_181662_b(x, y + height, 0).func_187315_a(0, 1).func_181675_d();
		buffer.func_181662_b(x + width, y + height, 0).func_187315_a(1, 1).func_181675_d();
		buffer.func_181662_b(x + width, y, 0).func_187315_a(1, 0).func_181675_d();
		buffer.func_181662_b(x, y, 0).func_187315_a(0, 0).func_181675_d();
		tessellator.func_78381_a();
	}

	public static void drawRectWithTexture(double x, double y, float u, float v, int width, int height, float textureWidth, float textureHeight, int sourceWidth, int sourceHeight)
	{
		float scaleWidth = 1.0F / sourceWidth;
		float scaleHeight = 1.0F / sourceHeight;
		Tessellator tessellator = Tessellator.func_178181_a();
		BufferBuilder buffer = tessellator.func_178180_c();
		buffer.func_181668_a(7, DefaultVertexFormats.field_181707_g);
		buffer.func_181662_b(x, y + height, 0).func_187315_a((double)(u * scaleWidth), (double)(v + textureHeight) * scaleHeight).func_181675_d();
		buffer.func_181662_b(x + width, y + height, 0).func_187315_a((double)(u + textureWidth) * scaleWidth, (double)(v + textureHeight) * scaleHeight).func_181675_d();
		buffer.func_181662_b(x + width, y, 0).func_187315_a((double)(u + textureWidth) * scaleWidth, (double)(v * scaleHeight)).func_181675_d();
		buffer.func_181662_b(x, y, 0).func_187315_a((double)(u * scaleWidth), (double)(v * scaleHeight)).func_181675_d();
		tessellator.func_78381_a();
	}

	public static void drawApplicationIcon(@Nullable AppInfo info, double x, double y)
	{
		//TODO: Reset color GlStateManager.color(1.0F, 1.0F, 1.0F);
		Minecraft.func_71410_x().func_110434_K().func_110577_a(Laptop.ICON_TEXTURES);
		if(info != null)
		{
			drawRectWithTexture(x, y, info.getIconU(), info.getIconV(), 14, 14, 14, 14, 224, 224);
		}
		else
		{
			drawRectWithTexture(x, y, 0, 0, 14, 14, 14, 14, 224, 224);
		}
	}

	public static void drawStringClipped(String text, int x, int y, int width, int color, boolean shadow)
	{
		Laptop.fontRenderer.func_175065_a(clipStringToWidth(text, width) + TextFormatting.RESET, x, y, color, shadow);
	}

	public static String clipStringToWidth(String text, int width)
	{
		FontRenderer fontRenderer = Laptop.fontRenderer;
		String clipped = text;
		if(fontRenderer.func_78256_a(clipped) > width)
		{
			clipped = fontRenderer.func_78269_a(clipped, width - 8) + "...";
		}
		return clipped;
	}

	public static boolean isMouseInside(int mouseX, int mouseY, int x1, int y1, int x2, int y2)
	{
		return mouseX >= x1 && mouseX <= x2 && mouseY >= y1 && mouseY <= y2;
	}

	public static int color(int color, int defaultColor)
	{
		return color != -1 && color > 0 ? color : defaultColor;
	}
}
