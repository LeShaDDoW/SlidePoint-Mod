package com.mrcrayfish.device.api.app.listener;

/**
 * Author: MrCrayfish
 */
public interface KeyListener
{
    boolean onKeyTyped(char c);
}
