package com.mrcrayfish.device.core.io;

import com.mrcrayfish.device.MrCrayfishDeviceMod;
import com.mrcrayfish.device.api.app.Application;
import com.mrcrayfish.device.api.io.Drive;
import com.mrcrayfish.device.api.io.Folder;
import com.mrcrayfish.device.api.task.Callback;
import com.mrcrayfish.device.api.task.Task;
import com.mrcrayfish.device.api.task.TaskManager;
import com.mrcrayfish.device.core.Laptop;
import com.mrcrayfish.device.core.io.action.FileAction;
import com.mrcrayfish.device.core.io.drive.AbstractDrive;
import com.mrcrayfish.device.core.io.drive.ExternalDrive;
import com.mrcrayfish.device.core.io.drive.InternalDrive;
import com.mrcrayfish.device.core.io.task.TaskGetFiles;
import com.mrcrayfish.device.core.io.task.TaskGetMainDrive;
import com.mrcrayfish.device.core.io.task.TaskSendAction;
import com.mrcrayfish.device.init.DeviceItems;
import com.mrcrayfish.device.tileentity.TileEntityLaptop;
import net.minecraft.item.EnumDyeColor;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.nbt.NBTTagList;
import net.minecraft.world.World;
import net.minecraftforge.common.util.Constants;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

import javax.annotation.Nullable;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.UUID;
import java.util.regex.Pattern;

public class FileSystem
{
	public static final Pattern PATTERN_FILE_NAME = Pattern.compile("^[\\w'. ]{1,32}$");
	public static final Pattern PATTERN_DIRECTORY = Pattern.compile("^(/)|(/[\\w'. ]{1,32})*$");

	public static final String DIR_ROOT = "/";
	public static final String DIR_APPLICATION_DATA = DIR_ROOT + "Application Data";
	public static final String DIR_HOME = DIR_ROOT + "Home";
	public static final String LAPTOP_DRIVE_NAME = "Root";

	private AbstractDrive mainDrive = null;
	private Map<UUID, AbstractDrive> additionalDrives = new HashMap<>();
	private AbstractDrive attachedDrive = null;
	private EnumDyeColor attachedDriveColor = EnumDyeColor.RED;

	private TileEntityLaptop tileEntity;
	
	public FileSystem(TileEntityLaptop tileEntity, NBTTagCompound fileSystemTag)
	{
		this.tileEntity = tileEntity;

		load(fileSystemTag);
	}

	private void load(NBTTagCompound fileSystemTag)
	{
		if(fileSystemTag.func_150297_b("main_drive", Constants.NBT.TAG_COMPOUND))
		{
			mainDrive = InternalDrive.fromTag(fileSystemTag.func_74775_l("main_drive"));
		}

		if(fileSystemTag.func_150297_b("drives", Constants.NBT.TAG_LIST))
		{
			NBTTagList tagList = fileSystemTag.func_150295_c("drives", Constants.NBT.TAG_COMPOUND);
			for(int i = 0; i < tagList.func_74745_c(); i++)
			{
				NBTTagCompound driveTag = tagList.func_150305_b(i);
				AbstractDrive drive = InternalDrive.fromTag(driveTag.func_74775_l("drive"));
				additionalDrives.put(drive.getUUID(), drive);
			}
		}

		if(fileSystemTag.func_150297_b("external_drive", Constants.NBT.TAG_COMPOUND))
		{
			attachedDrive = ExternalDrive.fromTag(fileSystemTag.func_74775_l("external_drive"));
		}

		if(fileSystemTag.func_150297_b("external_drive_color", Constants.NBT.TAG_BYTE))
		{
			attachedDriveColor = EnumDyeColor.func_176764_b(fileSystemTag.func_74771_c("external_drive_color"));
		}

		setupDefault();
	}

	/**
	 * Sets up the default folders for the file system if they don't exist.
	 */
	private void setupDefault()
	{
		if(mainDrive == null)
		{
			AbstractDrive drive = new InternalDrive(LAPTOP_DRIVE_NAME);
			ServerFolder root = drive.getRoot(tileEntity.func_145831_w());
			root.add(createProtectedFolder("Home"), false);
			root.add(createProtectedFolder("Application Data"), false);
			mainDrive = drive;
			tileEntity.func_70296_d();
		}
	}

	private ServerFolder createProtectedFolder(String name)
	{
		try
		{
			Constructor<ServerFolder> constructor = ServerFolder.class.getDeclaredConstructor(String.class, boolean.class);
			constructor.setAccessible(true);
			return constructor.newInstance(name, true);
		}
		catch(NoSuchMethodException | IllegalAccessException | InstantiationException | InvocationTargetException e)
		{
			e.printStackTrace();
		}
		return null;
	}

	@SideOnly(Side.CLIENT)
	public static void sendAction(Drive drive, FileAction action, @Nullable Callback<Response> callback)
	{
		if(Laptop.getPos() != null)
		{
			Task task = new TaskSendAction(drive, action);
			task.setCallback((nbt, success) ->
			{
				if(callback != null)
				{
					callback.execute(Response.fromTag(nbt.func_74775_l("response")), success);
				}
            });
			TaskManager.sendTask(task);
		}
	}

	public Response readAction(String driveUuid, FileAction action, World world)
	{
		UUID uuid = UUID.fromString(driveUuid);
		AbstractDrive drive = getAvailableDrives(world, true).get(uuid);
		if(drive != null)
		{
			Response response = drive.handleFileAction(this, action, world);
			if(response.getStatus() == Status.SUCCESSFUL)
			{
				tileEntity.func_70296_d();
			}
			return response;
		}
		return createResponse(Status.DRIVE_UNAVAILABLE, "Drive unavailable or missing");
	}

	public AbstractDrive getMainDrive()
	{
		return mainDrive;
	}

	public Map<UUID, AbstractDrive> getAvailableDrives(World world, boolean includeMain)
	{
		Map<UUID, AbstractDrive> drives = new LinkedHashMap<>();

		if(includeMain)
			drives.put(mainDrive.getUUID(), mainDrive);

		additionalDrives.forEach(drives::put);

		if(attachedDrive != null)
			drives.put(attachedDrive.getUUID(), attachedDrive);

		//TODO add network drives
		return drives;
	}

	public boolean setAttachedDrive(ItemStack flashDrive)
	{
		if(attachedDrive == null)
		{
			NBTTagCompound flashDriveTag = getExternalDriveTag(flashDrive);
			AbstractDrive drive = ExternalDrive.fromTag(flashDriveTag.func_74775_l("drive"));
			if(drive != null)
			{
				drive.setName(flashDrive.func_82833_r());
				attachedDrive = drive;
				attachedDriveColor = EnumDyeColor.func_176764_b(flashDrive.func_77960_j());

				tileEntity.getPipeline().func_74774_a("external_drive_color", (byte) attachedDriveColor.func_176765_a());
				tileEntity.sync();

				return true;
			}
		}
		return false;
	}

	public AbstractDrive getAttachedDrive()
	{
		return attachedDrive;
	}

	public EnumDyeColor getAttachedDriveColor()
	{
		return attachedDriveColor;
	}

	@Nullable
	public ItemStack removeAttachedDrive()
	{
		if(attachedDrive != null)
		{
			ItemStack stack = new ItemStack(DeviceItems.FLASH_DRIVE, 1, getAttachedDriveColor().func_176765_a());
			stack.func_151001_c(attachedDrive.getName());
			stack.func_77978_p().func_74782_a("drive", attachedDrive.toTag());
			attachedDrive = null;
			return stack;
		}
		return null;
	}

	private NBTTagCompound getExternalDriveTag(ItemStack stack)
	{
		NBTTagCompound tagCompound = stack.func_77978_p();
		if(tagCompound == null)
		{
			tagCompound = new NBTTagCompound();
			tagCompound.func_74782_a("drive", new ExternalDrive(stack.func_82833_r()).toTag());
			stack.func_77982_d(tagCompound);
		}
		else if(!tagCompound.func_150297_b("drive", Constants.NBT.TAG_COMPOUND))
		{
			tagCompound.func_74782_a("drive", new ExternalDrive(stack.func_82833_r()).toTag());
		}
		return tagCompound;
	}

	public static void getApplicationFolder(Application app, Callback<Folder> callback)
	{
		if(MrCrayfishDeviceMod.proxy.hasAllowedApplications())
		{
			if(!MrCrayfishDeviceMod.proxy.getAllowedApplications().contains(app.getInfo()))
			{
				callback.execute(null, false);
				return;
			}
		}
		if(Laptop.getMainDrive() == null)
		{
			Task task = new TaskGetMainDrive(Laptop.getPos());
			task.setCallback((nbt, success) ->
			{
				if(success)
				{
					setupApplicationFolder(app, callback);
				}
				else
				{
					callback.execute(null, false);
				}
			});
			TaskManager.sendTask(task);
		}
		else
		{
			setupApplicationFolder(app, callback);
		}
	}

	private static void setupApplicationFolder(Application app, Callback<Folder> callback)
	{
		Folder folder = Laptop.getMainDrive().getFolder(FileSystem.DIR_APPLICATION_DATA);
		if(folder != null)
		{
			if(folder.hasFolder(app.getInfo().getFormattedId()))
			{
				Folder appFolder = folder.getFolder(app.getInfo().getFormattedId());
				if(appFolder.isSynced())
				{
					callback.execute(appFolder, true);
				}
				else
				{
					Task task = new TaskGetFiles(appFolder, Laptop.getPos());
					task.setCallback((nbt, success) ->
					{
						if(success && nbt.func_150297_b("files", Constants.NBT.TAG_LIST))
						{
							NBTTagList files = nbt.func_150295_c("files", Constants.NBT.TAG_COMPOUND);
							appFolder.syncFiles(files);
							callback.execute(appFolder, true);
						}
						else
						{
							callback.execute(null, false);
						}
					});
					TaskManager.sendTask(task);
				}
			}
			else
			{
				Folder appFolder = new Folder(app.getInfo().getFormattedId());
				folder.add(appFolder, (response, success) ->
				{
					if(response != null && response.getStatus() == Status.SUCCESSFUL)
					{
						callback.execute(appFolder, true);
					}
					else
					{
						callback.execute(null, false);
					}
				});
			}
		}
		else
		{
			callback.execute(null, false);
		}
	}

	public NBTTagCompound toTag()
	{
		NBTTagCompound fileSystemTag = new NBTTagCompound();

		if(mainDrive != null)
			fileSystemTag.func_74782_a("main_drive", mainDrive.toTag());

		NBTTagList tagList = new NBTTagList();
		additionalDrives.forEach((k, v) -> tagList.func_74742_a(v.toTag()));
		fileSystemTag.func_74782_a("drives", tagList);

		if(attachedDrive != null)
		{
			fileSystemTag.func_74782_a("external_drive", attachedDrive.toTag());
			fileSystemTag.func_74774_a("external_drive_color", (byte) attachedDriveColor.func_176765_a());
		}

		return fileSystemTag;
	}

	public static Response createSuccessResponse()
	{
		return new Response(Status.SUCCESSFUL);
	}

	public static Response createResponse(int status, String message)
	{
		return new Response(status, message);
	}

	public static class Response
	{
		private final int status;
		private String message = "";

		private Response(int status)
		{
			this.status = status;
		}

		private Response(int status, String message)
		{
			this.status = status;
			this.message = message;
		}

		public int getStatus()
		{
			return status;
		}

		public String getMessage()
		{
			return message;
		}

		public NBTTagCompound toTag()
		{
			NBTTagCompound responseTag = new NBTTagCompound();
			responseTag.func_74768_a("status", status);
			responseTag.func_74778_a("message", message);
			return responseTag;
		}

		public static Response fromTag(NBTTagCompound responseTag)
		{
			return new Response(responseTag.func_74762_e("status"), responseTag.func_74779_i("message"));
		}
	}

	public static class Status
	{
		public static final int FAILED = 0;
		public static final int SUCCESSFUL = 1;
		public static final int FILE_INVALID = 2;
		public static final int FILE_IS_PROTECTED = 3;
		public static final int FILE_EXISTS = 4;
		public static final int FILE_INVALID_NAME = 5;
		public static final int FILE_INVALID_DATA = 6;
		public static final int DRIVE_UNAVAILABLE = 7;
	}
}
