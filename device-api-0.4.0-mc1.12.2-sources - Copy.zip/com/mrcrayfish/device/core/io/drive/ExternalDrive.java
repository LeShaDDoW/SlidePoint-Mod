package com.mrcrayfish.device.core.io.drive;

import com.mrcrayfish.device.core.io.ServerFolder;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraftforge.common.util.Constants;

import javax.annotation.Nullable;
import java.util.UUID;
import java.util.function.Predicate;

import com.mrcrayfish.device.core.io.drive.AbstractDrive.Type;

/**
 * Author: MrCrayfish
 */
public final class ExternalDrive extends AbstractDrive
{
    private static final Predicate<NBTTagCompound> PREDICATE_DRIVE_TAG = tag ->
            tag.func_150297_b("name", Constants.NBT.TAG_STRING)
            && tag.func_150297_b("uuid", Constants.NBT.TAG_STRING)
            && tag.func_150297_b("root", Constants.NBT.TAG_COMPOUND);

    private ExternalDrive() {}

    public ExternalDrive(String displayName)
    {
        super(displayName);
    }

    @Nullable
    public static AbstractDrive fromTag(NBTTagCompound driveTag)
    {
        if(!PREDICATE_DRIVE_TAG.test(driveTag))
            return null;

        AbstractDrive drive = new ExternalDrive();
        drive.name = driveTag.func_74779_i("name");
        drive.uuid = UUID.fromString(driveTag.func_74779_i("uuid"));

        NBTTagCompound folderTag = driveTag.func_74775_l("root");
        drive.root = ServerFolder.fromTag(folderTag.func_74779_i("file_name"), folderTag.func_74775_l("data"));

        return drive;
    }

    @Override
    public NBTTagCompound toTag()
    {
        NBTTagCompound driveTag = new NBTTagCompound();
        driveTag.func_74778_a("name", name);
        driveTag.func_74778_a("uuid", uuid.toString());

        NBTTagCompound folderTag = new NBTTagCompound();
        folderTag.func_74778_a("file_name", root.getName());
        folderTag.func_74782_a("data", root.toTag());
        driveTag.func_74782_a("root", folderTag);

        return driveTag;
    }

    @Override
    public Type getType()
    {
        return Type.EXTERNAL;
    }
}
