package com.mrcrayfish.device.core.io.drive;

import com.mrcrayfish.device.core.io.ServerFolder;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraftforge.common.util.Constants;

import javax.annotation.Nullable;

import com.mrcrayfish.device.core.io.drive.AbstractDrive.Type;

/**
 * Author: MrCrayfish
 */
public final class InternalDrive extends AbstractDrive
{
    public InternalDrive(String name)
    {
        super(name);
    }

    @Nullable
    public static AbstractDrive fromTag(NBTTagCompound driveTag)
    {
        AbstractDrive drive = new InternalDrive(driveTag.func_74779_i("name"));
        if(driveTag.func_150297_b("root", Constants.NBT.TAG_COMPOUND))
        {
            NBTTagCompound folderTag = driveTag.func_74775_l("root");
            drive.root = ServerFolder.fromTag(folderTag.func_74779_i("file_name"), folderTag.func_74775_l("data"));
        }
        return drive;
    }

    @Override
    public NBTTagCompound toTag()
    {
        NBTTagCompound driveTag = new NBTTagCompound();
        driveTag.func_74778_a("name", name);

        NBTTagCompound folderTag = new NBTTagCompound();
        folderTag.func_74778_a("file_name", root.getName());
        folderTag.func_74782_a("data", root.toTag());
        driveTag.func_74782_a("root", folderTag);

        return driveTag;
    }

    @Override
    public Type getType()
    {
        return Type.INTERNAL;
    }
}
