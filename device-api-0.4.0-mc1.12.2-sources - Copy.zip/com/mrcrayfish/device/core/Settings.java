package com.mrcrayfish.device.core;

import com.mrcrayfish.device.programs.system.object.ColorScheme;
import net.minecraft.nbt.NBTTagCompound;

/**
 * Author: MrCrayfish
 */
public class Settings
{
    private static boolean showAllApps = true;

    private ColorScheme colorScheme = new ColorScheme();

    public static void setShowAllApps(boolean showAllApps)
    {
        Settings.showAllApps = showAllApps;
    }

    public static boolean isShowAllApps()
    {
        return Settings.showAllApps;
    }

    public ColorScheme getColorScheme()
    {
        return colorScheme;
    }

    public NBTTagCompound toTag()
    {
        NBTTagCompound tag = new NBTTagCompound();
        tag.func_74757_a("showAllApps", showAllApps);
        tag.func_74782_a("colorScheme", colorScheme.toTag());
        return tag;
    }

    public static Settings fromTag(NBTTagCompound tag)
    {
        //showAllApps = tag.getBoolean("showAllApps");

        Settings settings = new Settings();
        settings.colorScheme = ColorScheme.fromTag(tag.func_74775_l("colorScheme"));
        return settings;
    }
}
