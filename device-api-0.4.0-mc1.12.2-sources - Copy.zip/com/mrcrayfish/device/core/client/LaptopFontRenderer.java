package com.mrcrayfish.device.core.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.util.ResourceLocation;

/**
 * Author: MrCrayfish
 */
public class LaptopFontRenderer extends FontRenderer
{
    private boolean debug = false;

    public LaptopFontRenderer(Minecraft mc)
    {
        super(mc.field_71474_y, new ResourceLocation("textures/font/ascii.png"), mc.func_110434_K(), false);
        this.func_110549_a(null);
    }

    @Override
    public int func_78263_a(char c)
    {
        switch(c)
        {
            case '\n': return 0;
            case '\t': return 20;
        }
        return super.func_78263_a(c);
    }

    @Override
    protected float func_78277_a(char c, boolean italic)
    {
        if(debug && (c == '\n' || c == '\t'))
        {
            super.func_78277_a(c, italic);
        }
        switch(c)
        {
            case '\n': return 0F;
            case '\t': return 20F;
        }
        return super.func_78277_a(c, italic);
    }

    public void setDebug(boolean debug)
    {
        this.debug = debug;
    }
}
