package com.mrcrayfish.device.core.client;

import com.mrcrayfish.device.api.app.IIcon;
import com.mrcrayfish.device.api.utils.RenderUtil;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.toasts.GuiToast;
import net.minecraft.client.gui.toasts.IToast;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.resources.I18n;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.common.util.Constants;

import net.minecraft.client.gui.toasts.IToast.Visibility;

/**
 * Author: MrCrayfish
 */
public class ClientNotification implements IToast
{
    private static final ResourceLocation TEXTURE_TOASTS = new ResourceLocation("cdm:textures/gui/toast.png");

    private IIcon icon;
    private String title;
    private String subTitle;

    private ClientNotification() {}

    @Override
    public Visibility func_193653_a(GuiToast toastGui, long delta)
    {
        GlStateManager.func_179124_c(1.0F, 1.0F, 1.0F);
        toastGui.func_192989_b().func_110434_K().func_110577_a(TEXTURE_TOASTS);
        toastGui.func_73729_b(0, 0, 0, 0, 160, 32);

        if(subTitle == null)
        {
            toastGui.func_192989_b().field_71466_p.func_175065_a(RenderUtil.clipStringToWidth(I18n.func_135052_a(title), 118), 38, 12, -1, true);
        }
        else
        {
            toastGui.func_192989_b().field_71466_p.func_175065_a(RenderUtil.clipStringToWidth(I18n.func_135052_a(title), 118), 38, 7, -1, true);
            toastGui.func_192989_b().field_71466_p.func_78276_b(RenderUtil.clipStringToWidth(I18n.func_135052_a(subTitle), 118), 38, 18, -1);
        }

        toastGui.func_192989_b().func_110434_K().func_110577_a(icon.getIconAsset());
        RenderUtil.drawRectWithTexture(6, 6, icon.getU(), icon.getV(), icon.getGridWidth(), icon.getGridHeight(), icon.getIconSize(), icon.getIconSize(), icon.getSourceWidth(), icon.getSourceHeight());

        return delta >= 5000L ? IToast.Visibility.HIDE : IToast.Visibility.SHOW;
    }

    public static ClientNotification loadFromTag(NBTTagCompound tag)
    {
        ClientNotification notification = new ClientNotification();

        int ordinal = tag.func_74775_l("icon").func_74762_e("ordinal");
        String className = tag.func_74775_l("icon").func_74779_i("className");

        try
        {
            notification.icon = (IIcon)Class.forName(className).getEnumConstants()[ordinal];
        }
        catch (ClassNotFoundException e)
        {
            e.printStackTrace();
        }

        notification.title = tag.func_74779_i("title");
        if(tag.func_150297_b("subTitle", Constants.NBT.TAG_STRING))
        {
            notification.subTitle = tag.func_74779_i("subTitle");
        }

        return notification;
    }

    public void push()
    {
        Minecraft.func_71410_x().func_193033_an().func_192988_a(this);
    }
}
