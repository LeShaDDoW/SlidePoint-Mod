package com.mrcrayfish.device.core;

import net.minecraft.client.gui.inventory.GuiContainer;
import net.minecraft.inventory.Container;

/**
 * Author: MrCrayfish
 */
public class Printer extends GuiContainer
{
    public Printer(Container inventorySlotsIn)
    {
        super(inventorySlotsIn);
    }

    @Override
    protected void func_146976_a(float partialTicks, int mouseX, int mouseY)
    {

    }
}
