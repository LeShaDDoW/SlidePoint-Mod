package com.mrcrayfish.device.core;

import com.google.common.collect.ImmutableList;
import com.mrcrayfish.device.MrCrayfishDeviceMod;
import com.mrcrayfish.device.Reference;
import com.mrcrayfish.device.api.ApplicationManager;
import com.mrcrayfish.device.api.app.Application;
import com.mrcrayfish.device.api.app.Dialog;
import com.mrcrayfish.device.api.app.Layout;
import com.mrcrayfish.device.api.app.System;
import com.mrcrayfish.device.api.app.component.Image;
import com.mrcrayfish.device.api.io.Drive;
import com.mrcrayfish.device.api.io.File;
import com.mrcrayfish.device.api.task.Callback;
import com.mrcrayfish.device.api.task.Task;
import com.mrcrayfish.device.api.task.TaskManager;
import com.mrcrayfish.device.api.utils.RenderUtil;
import com.mrcrayfish.device.core.client.LaptopFontRenderer;
import com.mrcrayfish.device.core.task.TaskInstallApp;
import com.mrcrayfish.device.object.AppInfo;
import com.mrcrayfish.device.programs.system.SystemApplication;
import com.mrcrayfish.device.programs.system.component.FileBrowser;
import com.mrcrayfish.device.programs.system.task.TaskUpdateApplicationData;
import com.mrcrayfish.device.programs.system.task.TaskUpdateSystemData;
import com.mrcrayfish.device.tileentity.TileEntityLaptop;
import com.mrcrayfish.device.util.GuiHelper;
import net.minecraft.client.Minecraft;
import net.minecraft.client.audio.PositionedSoundRecord;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.init.SoundEvents;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.nbt.NBTTagList;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.math.BlockPos;
import net.minecraftforge.common.util.Constants;
import org.lwjgl.input.Keyboard;
import org.lwjgl.input.Mouse;
import org.lwjgl.opengl.GL11;

import javax.annotation.Nullable;
import java.awt.Color;
import java.io.IOException;
import java.util.*;

//TODO Intro message (created by mrcrayfish, donate here)

public class Laptop extends GuiScreen implements System
{
	public static final int ID = 1;
	
	private static final ResourceLocation LAPTOP_GUI = new ResourceLocation(Reference.MOD_ID, "textures/gui/laptop.png");

	public static final ResourceLocation ICON_TEXTURES = new ResourceLocation(Reference.MOD_ID, "textures/atlas/app_icons.png");
	public static final int ICON_SIZE = 14;

	public static final FontRenderer fontRenderer = new LaptopFontRenderer(Minecraft.func_71410_x());

	private static final List<Application> APPLICATIONS = new ArrayList<>();
	private static final List<ResourceLocation> WALLPAPERS = new ArrayList<>();

	private static final int BORDER = 10;
	private static final int DEVICE_WIDTH = 384;
	private static final int DEVICE_HEIGHT = 216;
	static final int SCREEN_WIDTH = DEVICE_WIDTH - BORDER * 2;
	static final int SCREEN_HEIGHT = DEVICE_HEIGHT - BORDER * 2;

	private static System system;
	private static BlockPos pos;
	private static Drive mainDrive;

	private Settings settings;
	private TaskBar bar;
	private Window[] windows;
	private Layout context = null;

	private NBTTagCompound appData;
	private NBTTagCompound systemData;

	private int currentWallpaper;
	private int lastMouseX, lastMouseY;
	private boolean dragging = false;

	protected List<AppInfo> installedApps = new ArrayList<>();

	public Laptop(TileEntityLaptop laptop)
	{
		this.appData = laptop.getApplicationData();
		this.systemData = laptop.getSystemData();
		this.windows = new Window[5];
		this.settings = Settings.fromTag(systemData.func_74775_l("Settings"));
		this.bar = new TaskBar(this);
		this.currentWallpaper = systemData.func_74762_e("CurrentWallpaper");
		if(currentWallpaper < 0 || currentWallpaper >= WALLPAPERS.size()) {
			this.currentWallpaper = 0;
		}
		Laptop.system = this;
		Laptop.pos = laptop.func_174877_v();
	}

	/**
	 * Returns the position of the laptop the player is currently using. This method can ONLY be
	 * called when the laptop GUI is open, otherwise it will return a null position.
	 *
	 * @return the position of the laptop currently in use
	 */
	@Nullable
	public static BlockPos getPos()
	{
		return pos;
	}

	@Override
	public void func_73866_w_() 
	{
		Keyboard.enableRepeatEvents(true);
		int posX = (field_146294_l - DEVICE_WIDTH) / 2;
		int posY = (field_146295_m - DEVICE_HEIGHT) / 2;
		bar.init(posX + BORDER, posY + DEVICE_HEIGHT - 28);

		NBTTagList tagList = systemData.func_150295_c("InstalledApps", Constants.NBT.TAG_STRING);
		for(int i = 0; i < tagList.func_74745_c(); i++)
		{
			AppInfo info = ApplicationManager.getApplication(tagList.func_150307_f(i));
			if(info != null)
			{
				installedApps.add(info);
			}
		}
		installedApps.sort(AppInfo.SORT_NAME);
	}

	@Override
	public void func_146281_b()
    {
        Keyboard.enableRepeatEvents(false);

        /* Close all windows and sendTask application data */
        for(Window window : windows)
		{
        	if(window != null)
			{
        		window.close();
			}
		}

		/* Send system data */
        systemData.func_74768_a("CurrentWallpaper", currentWallpaper);
        systemData.func_74782_a("Settings", settings.toTag());
        TaskManager.sendTask(new TaskUpdateSystemData(pos, systemData));

		Laptop.pos = null;
        Laptop.system = null;
		Laptop.mainDrive = null;
    }
	
	@Override
	public void func_175273_b(Minecraft mcIn, int width, int height)
	{
		super.func_175273_b(mcIn, width, height);
		for(Window window : windows)
		{
			if(window != null)
			{
				window.content.markForLayoutUpdate();
			}
		}
	}
	
	@Override
	public void func_73876_c()
	{
		bar.onTick();

		for(Window window : windows)
		{
			if(window != null)
			{
				window.onTick();
			}
		}

		FileBrowser.refreshList = false;
	}
	
	@Override
	public void func_73863_a(int mouseX, int mouseY, float partialTicks) 
	{
		//Fixes the strange partialTicks that Forge decided to give us
		partialTicks = Minecraft.func_71410_x().func_184121_ak();

		this.func_146276_q_();
		
		GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
		this.field_146297_k.func_110434_K().func_110577_a(LAPTOP_GUI);
		
		/* Physical Screen */
		int posX = (field_146294_l - DEVICE_WIDTH) / 2;
		int posY = (field_146295_m - DEVICE_HEIGHT) / 2;
		
		/* Corners */
		this.func_73729_b(posX, posY, 0, 0, BORDER, BORDER); // TOP-LEFT
		this.func_73729_b(posX + DEVICE_WIDTH - BORDER, posY, 11, 0, BORDER, BORDER); // TOP-RIGHT
		this.func_73729_b(posX + DEVICE_WIDTH - BORDER, posY + DEVICE_HEIGHT - BORDER, 11, 11, BORDER, BORDER); // BOTTOM-RIGHT
		this.func_73729_b(posX, posY + DEVICE_HEIGHT - BORDER, 0, 11, BORDER, BORDER); // BOTTOM-LEFT
		
		/* Edges */
		RenderUtil.drawRectWithTexture(posX + BORDER, posY, 10, 0, SCREEN_WIDTH, BORDER, 1, BORDER); // TOP
		RenderUtil.drawRectWithTexture(posX + DEVICE_WIDTH - BORDER, posY + BORDER, 11, 10, BORDER, SCREEN_HEIGHT, BORDER, 1); // RIGHT
		RenderUtil.drawRectWithTexture(posX + BORDER, posY + DEVICE_HEIGHT - BORDER, 10, 11, SCREEN_WIDTH, BORDER, 1, BORDER); // BOTTOM
		RenderUtil.drawRectWithTexture(posX, posY + BORDER, 0, 11, BORDER, SCREEN_HEIGHT, BORDER, 1); // LEFT
		
		/* Center */
		RenderUtil.drawRectWithTexture(posX + BORDER, posY + BORDER, 10, 10, SCREEN_WIDTH, SCREEN_HEIGHT, 1, 1);
		
		/* Wallpaper */
		this.field_146297_k.func_110434_K().func_110577_a(WALLPAPERS.get(currentWallpaper));
		RenderUtil.drawRectWithFullTexture(posX + 10, posY + 10, 0, 0, SCREEN_WIDTH, SCREEN_HEIGHT);

		if(!MrCrayfishDeviceMod.DEVELOPER_MODE)
		{
			func_73731_b(fontRenderer, "Alpha v" + Reference.VERSION, posX + BORDER + 5, posY + BORDER + 5, Color.WHITE.getRGB());
		}
		else
		{
			func_73731_b(fontRenderer, "Developer Version - " + Reference.VERSION, posX + BORDER + 5, posY + BORDER + 5, Color.WHITE.getRGB());
		}

		boolean insideContext = false;
		if(context != null)
		{
			insideContext = GuiHelper.isMouseInside(mouseX, mouseY, context.xPosition, context.yPosition, context.xPosition + context.width, context.yPosition + context.height);
		}

		Image.CACHE.forEach((s, cachedImage) -> cachedImage.delete());

		/* Window */
		for(int i = windows.length - 1; i >= 0; i--)
		{
			Window window = windows[i];
			if(window != null)
			{
				window.render(this, field_146297_k, posX + BORDER, posY + BORDER, mouseX, mouseY, i == 0 && !insideContext, partialTicks);
			}
		}

		/* Application Bar */
		bar.render(this, field_146297_k, posX + 10, posY + DEVICE_HEIGHT - 28, mouseX, mouseY, partialTicks);

		if(context != null)
		{
			context.render(this, field_146297_k, context.xPosition, context.yPosition, mouseX, mouseY, true, partialTicks);
		}

		Image.CACHE.entrySet().removeIf(entry ->
		{
			Image.CachedImage cachedImage = entry.getValue();
			if(cachedImage.isDynamic() && cachedImage.isPendingDeletion())
			{
				int texture = cachedImage.getTextureId();
				if(texture != -1)
				{
					GL11.glDeleteTextures(texture);
				}
				return true;
			}
			return false;
		});

		super.func_73863_a(mouseX, mouseY, partialTicks);
	}
	
	@Override
	protected void func_73864_a(int mouseX, int mouseY, int mouseButton) throws IOException
	{
		this.lastMouseX = mouseX;
		this.lastMouseY = mouseY;
		
		int posX = (field_146294_l - SCREEN_WIDTH) / 2;
		int posY = (field_146295_m - SCREEN_HEIGHT) / 2;

		if(this.context != null)
		{
			int dropdownX = context.xPosition;
			int dropdownY = context.yPosition;
			if(GuiHelper.isMouseInside(mouseX, mouseY, dropdownX, dropdownY, dropdownX + context.width, dropdownY + context.height))
			{
				this.context.handleMouseClick(mouseX, mouseY, mouseButton);
				return;
			}
			else
			{
				this.context = null;
			}
		}

		this.bar.handleClick(this, posX, posY + SCREEN_HEIGHT - TaskBar.BAR_HEIGHT, mouseX, mouseY, mouseButton);

		for(int i = 0; i < windows.length; i++)
		{
			Window<Application> window = windows[i];
			if(window != null)
			{
				Window<Dialog> dialogWindow = window.getContent().getActiveDialog();
				if(isMouseWithinWindow(mouseX, mouseY, window) || isMouseWithinWindow(mouseX, mouseY, dialogWindow))
				{
					windows[i] = null;
					updateWindowStack();
					windows[0] = window;

					windows[0].handleMouseClick(this, posX, posY, mouseX, mouseY, mouseButton);
					
					if(isMouseWithinWindowBar(mouseX, mouseY, dialogWindow))
					{
						this.dragging = true;
						return;
					}
		
					if(isMouseWithinWindowBar(mouseX, mouseY, window) && dialogWindow == null)
					{
						this.dragging = true;
						return;
					}
					break;
				}
			}
		}
		
		super.func_73864_a(mouseX, mouseY, mouseButton);
	}
	
	@Override
	protected void func_146286_b(int mouseX, int mouseY, int state) 
	{
		super.func_146286_b(mouseX, mouseY, state);
		this.dragging = false;
		if(this.context != null)
		{
			int dropdownX = context.xPosition;
			int dropdownY = context.yPosition;
			if(GuiHelper.isMouseInside(mouseX, mouseY, dropdownX, dropdownY, dropdownX + context.width, dropdownY + context.height))
			{
				this.context.handleMouseRelease(mouseX, mouseY, state);
			}
		}
		else if(windows[0] != null)
		{
			windows[0].handleMouseRelease(mouseX, mouseY, state);
		}
	}
	
	@Override
	public void func_146282_l() throws IOException
    {
        if (Keyboard.getEventKeyState())
        {
        	char pressed = Keyboard.getEventCharacter();
        	int code = Keyboard.getEventKey();

            if(windows[0] != null)
    		{
    			windows[0].handleKeyTyped(pressed, code);
    		}
            
            super.func_73869_a(pressed, code);
        }
        else
        {
        	if(windows[0] != null)
    		{
    			windows[0].handleKeyReleased(Keyboard.getEventCharacter(), Keyboard.getEventKey());
    		}
        }

        this.field_146297_k.func_152348_aa();
    }
	
	@Override
	protected void func_146273_a(int mouseX, int mouseY, int clickedMouseButton, long timeSinceLastClick) 
	{
		int posX = (field_146294_l - SCREEN_WIDTH) / 2;
		int posY = (field_146295_m - SCREEN_HEIGHT) / 2;

		if(this.context != null)
		{
			int dropdownX = context.xPosition;
			int dropdownY = context.yPosition;
			if(GuiHelper.isMouseInside(mouseX, mouseY, dropdownX, dropdownY, dropdownX + context.width, dropdownY + context.height))
			{
				this.context.handleMouseDrag(mouseX, mouseY, clickedMouseButton);
			}
			return;
		}

		if(windows[0] != null)
		{
			Window<Application> window = windows[0];
			Window<Dialog> dialogWindow = window.getContent().getActiveDialog();
			if(dragging)
			{
				if(isMouseOnScreen(mouseX, mouseY))
				{
					if(dialogWindow == null)
					{
						window.handleWindowMove(posX, posY, -(lastMouseX - mouseX), -(lastMouseY - mouseY));
					}
					else
					{
						dialogWindow.handleWindowMove(posX, posY, -(lastMouseX - mouseX), -(lastMouseY - mouseY));
					}
				}
				else
				{
					dragging = false;
				}
			}
			else
			{
				if(isMouseWithinWindow(mouseX, mouseY, window) || isMouseWithinWindow(mouseX, mouseY, dialogWindow))
				{
					window.handleMouseDrag(mouseX, mouseY, clickedMouseButton);
				}
			}
		}
		this.lastMouseX = mouseX;
		this.lastMouseY = mouseY;
	}
	
	@Override
	public void func_146274_d() throws IOException
	{
		super.func_146274_d();
		int mouseX = Mouse.getEventX() * this.field_146294_l / this.field_146297_k.field_71443_c;
        int mouseY = this.field_146295_m - Mouse.getEventY() * this.field_146295_m / this.field_146297_k.field_71440_d - 1;
		int scroll = Mouse.getEventDWheel();
		if(scroll != 0)
		{
			if(windows[0] != null)
			{
				windows[0].handleMouseScroll(mouseX, mouseY, scroll >= 0);
			}
		}
	}

	@Override
	public void func_146283_a(List<String> textLines, int x, int y) 
	{
		super.func_146283_a(textLines, x, y);
	}

	public boolean sendApplicationToFront(AppInfo info)
	{
		for(int i = 0; i < windows.length; i++)
		{
			Window window = windows[i];
			if(window != null && window.content instanceof Application && ((Application) window.content).getInfo() == info)
			{
				windows[i] = null;
				updateWindowStack();
				windows[0] = window;
				return true;
			}
		}
		return false;
	}

	@Override
	public void openApplication(AppInfo info)
	{
		openApplication(info, (NBTTagCompound) null);
	}

	@Override
	public void openApplication(AppInfo info, NBTTagCompound intentTag)
	{
		Optional<Application> optional = APPLICATIONS.stream().filter(app -> app.getInfo() == info).findFirst();
		optional.ifPresent(application -> openApplication(application, intentTag));
	}

	private void openApplication(Application app, NBTTagCompound intent)
	{
		if(!isApplicationInstalled(app.getInfo()))
			return;

		if(!isValidApplication(app.getInfo()))
			return;

		if(sendApplicationToFront(app.getInfo()))
			return;

		Window<Application> window = new Window<>(app, this);
		window.init((field_146294_l - SCREEN_WIDTH) / 2, (field_146295_m - SCREEN_HEIGHT) / 2, intent);

		if(appData.func_74764_b(app.getInfo().getFormattedId()))
		{
			app.load(appData.func_74775_l(app.getInfo().getFormattedId()));
		}

		if(app instanceof SystemApplication)
		{
			((SystemApplication) app).setLaptop(this);
		}

		if(app.getCurrentLayout() == null)
		{
			app.restoreDefaultLayout();
		}
		
		addWindow(window);

	    Minecraft.func_71410_x().func_147118_V().func_147682_a(PositionedSoundRecord.func_184371_a(SoundEvents.field_187909_gi, 1.0F));
	}

	@Override
	public boolean openApplication(AppInfo info, File file)
	{
		if(!isApplicationInstalled(info))
			return false;

		if(!isValidApplication(info))
			return false;

		Optional<Application> optional = APPLICATIONS.stream().filter(app -> app.getInfo() == info).findFirst();
		if(optional.isPresent())
		{
			Application application = optional.get();
			boolean alreadyRunning = isApplicationRunning(info);
			openApplication(application, null);
			if(isApplicationRunning(info))
			{
				if(!application.handleFile(file))
				{
					if(!alreadyRunning)
					{
						closeApplication(application);
					}
					return false;
				}
				return true;
			}
		}
		return false;
	}

	@Override
	public void closeApplication(AppInfo info)
	{
		Optional<Application> optional = APPLICATIONS.stream().filter(app -> app.getInfo() == info).findFirst();
		optional.ifPresent(this::closeApplication);
	}

	private void closeApplication(Application app)
	{
		for(int i = 0; i < windows.length; i++)
		{
			Window<Application> window = windows[i];
			if(window != null)
			{
				if(window.content.getInfo().equals(app.getInfo()))
				{
					if(app.isDirty())
					{
						NBTTagCompound container = new NBTTagCompound();
						app.save(container);
						app.clean();
						appData.func_74782_a(app.getInfo().getFormattedId(), container);
						TaskManager.sendTask(new TaskUpdateApplicationData(pos.func_177958_n(), pos.func_177956_o(), pos.func_177952_p(), app.getInfo().getFormattedId(), container));
					}

					if(app instanceof SystemApplication)
					{
						((SystemApplication) app).setLaptop(null);
					}

					window.handleClose();
					windows[i] = null;
					return;
				}
			}
		}
	}
	
	private void addWindow(Window<Application> window)
	{
		if(hasReachedWindowLimit())
			return;

		updateWindowStack();
		windows[0] = window;
	}

	private void updateWindowStack()
	{
		for(int i = windows.length - 1; i >= 0; i--)
		{
			if(windows[i] != null)
			{
				if(i + 1 < windows.length)
				{
					if(i == 0 || windows[i - 1] != null)
					{
						if(windows[i + 1] == null)
						{
							windows[i + 1] = windows[i];
							windows[i] = null;
						}
					}
				}
			}
		}
	}

	private boolean hasReachedWindowLimit()
	{
		for(Window window : windows)
		{
			if(window == null) return false;
		}
		return true;
	}

	private boolean isMouseOnScreen(int mouseX, int mouseY)
	{
		int posX = (field_146294_l - SCREEN_WIDTH) / 2;
		int posY = (field_146295_m - SCREEN_HEIGHT) / 2;
		return GuiHelper.isMouseInside(mouseX, mouseY, posX, posY, posX + SCREEN_WIDTH, posY + SCREEN_HEIGHT);
	}

	private boolean isMouseWithinWindowBar(int mouseX, int mouseY, Window window)
	{
		if(window == null) return false;
		int posX = (field_146294_l - SCREEN_WIDTH) / 2;
		int posY = (field_146295_m - SCREEN_HEIGHT) / 2;
		return GuiHelper.isMouseInside(mouseX, mouseY, posX + window.offsetX + 1, posY + window.offsetY + 1, posX + window.offsetX + window.width - 13, posY + window.offsetY + 11);
	}

	private boolean isMouseWithinWindow(int mouseX, int mouseY, Window window)
	{
		if(window == null) return false;
		int posX = (field_146294_l - SCREEN_WIDTH) / 2;
		int posY = (field_146295_m - SCREEN_HEIGHT) / 2;
		return GuiHelper.isMouseInside(mouseX, mouseY, posX + window.offsetX, posY + window.offsetY, posX + window.offsetX + window.width, posY + window.offsetY + window.height);
	}
	
	public boolean isMouseWithinApp(int mouseX, int mouseY, Window window)
	{
		int posX = (field_146294_l - SCREEN_WIDTH) / 2;
		int posY = (field_146295_m - SCREEN_HEIGHT) / 2;
		return GuiHelper.isMouseInside(mouseX, mouseY, posX + window.offsetX + 1, posY + window.offsetY + 13, posX + window.offsetX + window.width - 1, posY + window.offsetY + window.height - 1);
	}

	public boolean isApplicationRunning(AppInfo info)
	{
		for(Window window : windows) 
		{
			if(window != null && ((Application) window.content).getInfo() == info)
			{
				return true;
			}
		}
		return false;
	}

	public void nextWallpaper()
	{
		if(currentWallpaper + 1 < WALLPAPERS.size())
		{
			currentWallpaper++;
		}
	}
	
	public void prevWallpaper()
	{
		if(currentWallpaper - 1 >= 0)
		{
			currentWallpaper--;
		}
	}

	public int getCurrentWallpaper()
	{
		return currentWallpaper;
	}

	public static void addWallpaper(ResourceLocation wallpaper)
	{
		if(wallpaper != null)
		{
			WALLPAPERS.add(wallpaper);
		}
	}

	public List<ResourceLocation> getWallapapers()
	{
		return ImmutableList.copyOf(WALLPAPERS);
	}

	@Nullable
	public Application getApplication(String appId)
	{
		return APPLICATIONS.stream().filter(app -> app.getInfo().getFormattedId().equals(appId)).findFirst().orElse(null);
	}

	@Override
	public List<AppInfo> getInstalledApplications()
	{
		return ImmutableList.copyOf(installedApps);
	}

	public boolean isApplicationInstalled(AppInfo info)
	{
		return info.isSystemApp() || installedApps.contains(info);
	}

	private boolean isValidApplication(AppInfo info)
	{
		if(MrCrayfishDeviceMod.proxy.hasAllowedApplications())
		{
			return MrCrayfishDeviceMod.proxy.getAllowedApplications().contains(info);
		}
		return true;
	}

	public void installApplication(AppInfo info, @Nullable Callback<Object> callback)
	{
		if(!isValidApplication(info))
			return;

		Task task = new TaskInstallApp(info, pos, true);
		task.setCallback((tagCompound, success) ->
		{
            if(success)
			{
				installedApps.add(info);
				installedApps.sort(AppInfo.SORT_NAME);
			}
			if(callback != null)
			{
				callback.execute(null, success);
			}
        });
		TaskManager.sendTask(task);
	}

	public void removeApplication(AppInfo info, @Nullable Callback<Object> callback)
	{
		if(!isValidApplication(info))
			return;

		Task task = new TaskInstallApp(info, pos, false);
		task.setCallback((tagCompound, success) ->
		{
			if(success)
			{
				installedApps.remove(info);
			}
			if(callback != null)
			{
				callback.execute(null, success);
			}
		});
		TaskManager.sendTask(task);
	}

	public static System getSystem()
	{
		return system;
	}

	public static void setMainDrive(Drive mainDrive)
	{
		if(Laptop.mainDrive == null)
		{
			Laptop.mainDrive = mainDrive;
		}
	}

	@Nullable
	public static Drive getMainDrive()
	{
		return mainDrive;
	}

	public List<Application> getApplications()
	{
		return APPLICATIONS;
	}

	public TaskBar getTaskBar()
	{
		return bar;
	}

	public Settings getSettings()
	{
		return settings;
	}

	@Override
	public boolean func_73868_f()
	{
		return false;
	}

	@Override
	public void openContext(Layout layout, int x, int y)
	{
		layout.updateComponents(x, y);
		context = layout;
		layout.init();
	}

	@Override
	public boolean hasContext()
	{
		return context != null;
	}

	@Override
	public void closeContext()
	{
		context = null;
		dragging = false;
	}
}
