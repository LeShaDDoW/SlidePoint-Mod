package com.mrcrayfish.device.core.network;

import java.util.UUID;

/**
 * Author: MrCrayfish
 */
public interface IDevice
{
    UUID getId();
}
