package com.mrcrayfish.device.block;

import com.mrcrayfish.device.api.print.IPrint;
import com.mrcrayfish.device.object.Bounds;
import com.mrcrayfish.device.tileentity.TileEntityPaper;
import com.mrcrayfish.device.util.CollisionHelper;
import net.minecraft.block.BlockHorizontal;
import net.minecraft.block.ITileEntityProvider;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.BlockStateContainer;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.EnumBlockRenderType;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;

import javax.annotation.Nullable;
import java.util.Random;

/**
 * Author: MrCrayfish
 */
public class BlockPaper extends BlockHorizontal implements ITileEntityProvider
{
    private static final Bounds SELECTION_BOUNDS = new Bounds(15 * 0.0625, 0.0, 0.0, 16 * 0.0625, 16 * 0.0625, 16 * 0.0625);
    private static final AxisAlignedBB SELECTION_BOX_NORTH = CollisionHelper.getBlockBounds(EnumFacing.NORTH, SELECTION_BOUNDS);
    private static final AxisAlignedBB SELECTION_BOX_EAST = CollisionHelper.getBlockBounds(EnumFacing.EAST, SELECTION_BOUNDS);
    private static final AxisAlignedBB SELECTION_BOX_SOUTH = CollisionHelper.getBlockBounds(EnumFacing.SOUTH, SELECTION_BOUNDS);
    private static final AxisAlignedBB SELECTION_BOX_WEST = CollisionHelper.getBlockBounds(EnumFacing.WEST, SELECTION_BOUNDS);
    private static final AxisAlignedBB[] SELECTION_BOUNDING_BOX = { SELECTION_BOX_SOUTH, SELECTION_BOX_WEST, SELECTION_BOX_NORTH, SELECTION_BOX_EAST };
    
    public BlockPaper()
    {
        super(Material.field_151580_n);
        this.func_149663_c("paper");
        this.setRegistryName("paper");
        this.func_180632_j(this.field_176227_L.func_177621_b().func_177226_a(field_185512_D, EnumFacing.NORTH));
    }

    @Override
    public boolean func_149662_c(IBlockState state)
    {
        return false;
    }

    @Override
    public boolean func_149686_d(IBlockState state)
    {
        return false;
    }

    @Override
    public AxisAlignedBB func_185496_a(IBlockState state, IBlockAccess source, BlockPos pos)
    {
        return SELECTION_BOUNDING_BOX[state.func_177229_b(field_185512_D).func_176736_b()];
    }

    @Nullable
    @Override
    public AxisAlignedBB func_180646_a(IBlockState blockState, IBlockAccess worldIn, BlockPos pos)
    {
        return null;
    }

    @Override
    public IBlockState getStateForPlacement(World world, BlockPos pos, EnumFacing facing, float hitX, float hitY, float hitZ, int meta, EntityLivingBase placer, EnumHand hand)
    {
        IBlockState state = super.getStateForPlacement(world, pos, facing, hitX, hitY, hitZ, meta, placer, hand);
        return state.func_177226_a(field_185512_D, placer.func_174811_aO());
    }

    @Override
    public boolean func_180639_a(World worldIn, BlockPos pos, IBlockState state, EntityPlayer playerIn, EnumHand hand, EnumFacing facing, float hitX, float hitY, float hitZ)
    {
        if(!worldIn.field_72995_K)
        {
            TileEntity tileEntity = worldIn.func_175625_s(pos);
            if(tileEntity instanceof TileEntityPaper)
            {
                TileEntityPaper paper = (TileEntityPaper) tileEntity;
                paper.nextRotation();
            }
        }
        return true;
    }

    @Override
    public Item func_180660_a(IBlockState state, Random rand, int fortune)
    {
        return null;
    }

    @Override
    public boolean removedByPlayer(IBlockState state, World world, BlockPos pos, EntityPlayer player, boolean willHarvest)
    {
        if(!world.field_72995_K && !player.field_71075_bZ.field_75098_d)
        {
            TileEntity tileEntity = world.func_175625_s(pos);
            if(tileEntity instanceof TileEntityPaper)
            {
                TileEntityPaper paper = (TileEntityPaper) tileEntity;
                ItemStack drop = IPrint.generateItem(paper.getPrint());
                world.func_72838_d(new EntityItem(world, pos.func_177958_n() + 0.5, pos.func_177956_o() + 0.5, pos.func_177952_p() + 0.5, drop));
            }
        }
        return super.removedByPlayer(state, world, pos, player, willHarvest);
    }

    @Override
    public boolean func_189539_a(IBlockState state, World worldIn, BlockPos pos, int id, int param)
    {
        TileEntity tileentity = worldIn.func_175625_s(pos);
        return tileentity != null && tileentity.func_145842_c(id, param);
    }

    @Override
    public int func_176201_c(IBlockState state)
    {
        return state.func_177229_b(field_185512_D).func_176736_b();
    }

    @Override
    public IBlockState func_176203_a(int meta)
    {
        return this.func_176223_P().func_177226_a(field_185512_D, EnumFacing.func_176731_b(meta));
    }

    @Override
    protected BlockStateContainer func_180661_e()
    {
        return new BlockStateContainer(this, field_185512_D);
    }

    public EnumBlockRenderType func_149645_b(IBlockState state)
    {
        return EnumBlockRenderType.ENTITYBLOCK_ANIMATED;
    }

    @Nullable
    @Override
    public TileEntity func_149915_a(World worldIn, int meta)
    {
        return new TileEntityPaper();
    }


}
