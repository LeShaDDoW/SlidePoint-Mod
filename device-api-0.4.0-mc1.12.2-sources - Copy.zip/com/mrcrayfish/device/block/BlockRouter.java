package com.mrcrayfish.device.block;

import com.mrcrayfish.device.MrCrayfishDeviceMod;
import com.mrcrayfish.device.network.PacketHandler;
import com.mrcrayfish.device.network.task.MessageSyncBlock;
import com.mrcrayfish.device.object.Bounds;
import com.mrcrayfish.device.tileentity.TileEntityRouter;
import com.mrcrayfish.device.util.IColored;
import net.minecraft.block.Block;
import net.minecraft.block.BlockColored;
import net.minecraft.block.ITileEntityProvider;
import net.minecraft.block.material.Material;
import net.minecraft.block.properties.PropertyBool;
import net.minecraft.block.state.BlockStateContainer;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;

import javax.annotation.Nullable;
import java.util.List;

/**
 * Author: MrCrayfish
 */
public class BlockRouter extends BlockDevice.Colored
{
    public static final PropertyBool VERTICAL = PropertyBool.func_177716_a("vertical");

    private static final AxisAlignedBB[] BODY_BOUNDING_BOX = new Bounds(4, 0, 2, 12, 2, 14).getRotatedBounds();
    private static final AxisAlignedBB[] BODY_VERTICAL_BOUNDING_BOX = new Bounds(14, 1, 2, 16, 9, 14).getRotatedBounds();
    private static final AxisAlignedBB[] SELECTION_BOUNDING_BOX = new Bounds(3, 0, 1, 13, 3, 15).getRotatedBounds();
    private static final AxisAlignedBB[] SELECTION_VERTICAL_BOUNDING_BOX = new Bounds(13, 0, 1, 16, 10, 15).getRotatedBounds();

    public BlockRouter()
    {
        super(Material.field_151574_g);
        this.func_180632_j(this.field_176227_L.func_177621_b().func_177226_a(field_185512_D, EnumFacing.NORTH).func_177226_a(VERTICAL, false));
        this.func_149647_a(MrCrayfishDeviceMod.TAB_DEVICE);
        this.func_149663_c("router");
        this.setRegistryName("router");
    }

    @Override
    public AxisAlignedBB func_185496_a(IBlockState state, IBlockAccess source, BlockPos pos)
    {
        if(state.func_177229_b(VERTICAL))
        {
            return SELECTION_VERTICAL_BOUNDING_BOX[state.func_177229_b(field_185512_D).func_176736_b()];
        }
        return SELECTION_BOUNDING_BOX[state.func_177229_b(field_185512_D).func_176736_b()];
    }

    @Override
    public void func_185477_a(IBlockState state, World worldIn, BlockPos pos, AxisAlignedBB entityBox, List<AxisAlignedBB> collidingBoxes, @Nullable Entity entityIn, boolean p_185477_7_)
    {
        if(state.func_177229_b(VERTICAL))
        {
            Block.func_185492_a(pos, entityBox, collidingBoxes, BODY_VERTICAL_BOUNDING_BOX[state.func_177229_b(field_185512_D).func_176736_b()]);
        }
        else
        {
            Block.func_185492_a(pos, entityBox, collidingBoxes, BODY_BOUNDING_BOX[state.func_177229_b(field_185512_D).func_176736_b()]);
        }
    }

    @Override
    public boolean func_180639_a(World worldIn, BlockPos pos, IBlockState state, EntityPlayer playerIn, EnumHand hand, EnumFacing facing, float hitX, float hitY, float hitZ)
    {
        if(worldIn.field_72995_K && playerIn.field_71075_bZ.field_75098_d)
        {
            TileEntity tileEntity = worldIn.func_175625_s(pos);
            if(tileEntity instanceof TileEntityRouter)
            {
                TileEntityRouter tileEntityRouter = (TileEntityRouter) tileEntity;
                tileEntityRouter.setDebug();
                if(tileEntityRouter.isDebug())
                {
                    PacketHandler.INSTANCE.sendToServer(new MessageSyncBlock(pos));
                }
            }
            return true;
        }
        return true;
    }

    @Override
    public IBlockState getStateForPlacement(World world, BlockPos pos, EnumFacing facing, float hitX, float hitY, float hitZ, int meta, EntityLivingBase placer, EnumHand hand)
    {
        IBlockState state = super.getStateForPlacement(world, pos, facing, hitX, hitY, hitZ, meta, placer, hand);
        return state.func_177226_a(VERTICAL, facing.func_176736_b() != -1);
    }

    @Override
    public boolean func_176198_a(World worldIn, BlockPos pos, EnumFacing side)
    {
        return side != EnumFacing.DOWN;
    }

    @Nullable
    @Override
    public TileEntity createTileEntity(World world, IBlockState state)
    {
        return new TileEntityRouter();
    }

    @Override
    public int func_176201_c(IBlockState state)
    {
        return state.func_177229_b(field_185512_D).func_176736_b() + (state.func_177229_b(VERTICAL) ? 4 : 0);
    }

    @Override
    public IBlockState func_176203_a(int meta)
    {
        return super.func_176203_a(meta).func_177226_a(VERTICAL, meta - 4 >= 0);
    }

    @Override
    protected BlockStateContainer func_180661_e()
    {
        return new BlockStateContainer(this, field_185512_D, VERTICAL, BlockColored.field_176581_a);
    }
}
