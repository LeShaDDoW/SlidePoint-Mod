package com.mrcrayfish.device.block;

import com.mrcrayfish.device.MrCrayfishDeviceMod;
import com.mrcrayfish.device.core.Laptop;
import com.mrcrayfish.device.init.DeviceItems;
import com.mrcrayfish.device.object.Bounds;
import com.mrcrayfish.device.tileentity.TileEntityLaptop;
import com.mrcrayfish.device.util.TileEntityUtil;
import net.minecraft.block.Block;
import net.minecraft.block.BlockColored;
import net.minecraft.block.ITileEntityProvider;
import net.minecraft.block.material.Material;
import net.minecraft.block.properties.PropertyEnum;
import net.minecraft.block.state.BlockStateContainer;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.Entity;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.BlockRenderLayer;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.IStringSerializable;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;

import javax.annotation.Nullable;
import java.util.List;

public class BlockLaptop extends BlockDevice.Colored
{
	public static final PropertyEnum TYPE = PropertyEnum.func_177709_a("type", Type.class);

	private static final AxisAlignedBB[] SCREEN_BOXES = new Bounds(13 * 0.0625, 0.0625, 1 * 0.0625, 1.0, 12 * 0.0625, 0.9375).getRotatedBounds();
	private static final AxisAlignedBB BODY_OPEN_BOX = new AxisAlignedBB(1 * 0.0625, 0.0, 1 * 0.0625, 13 * 0.0625, 1 * 0.0625, 15 * 0.0625);
	private static final AxisAlignedBB BODY_CLOSED_BOX = new AxisAlignedBB(1 * 0.0625, 0.0, 1 * 0.0625, 13 * 0.0625, 2 * 0.0625, 15 * 0.0625);
	private static final AxisAlignedBB SELECTION_BOX_OPEN = new AxisAlignedBB(0, 0, 0, 1, 12 * 0.0625, 1);
	private static final AxisAlignedBB SELECTION_BOX_CLOSED = new AxisAlignedBB(0, 0, 0, 1, 3 * 0.0625, 1);

	public BlockLaptop() 
	{
		super(Material.field_151574_g);
		this.func_180632_j(this.field_176227_L.func_177621_b().func_177226_a(field_185512_D, EnumFacing.NORTH).func_177226_a(TYPE, Type.BASE));
		this.func_149647_a(MrCrayfishDeviceMod.TAB_DEVICE);
		this.func_149663_c("laptop");
		this.setRegistryName("laptop");
	}

	@Override
	public AxisAlignedBB func_185496_a(IBlockState state, IBlockAccess source, BlockPos pos) 
	{
		TileEntity tileEntity = source.func_175625_s(pos);
		if(tileEntity instanceof TileEntityLaptop)
		{
			TileEntityLaptop laptop = (TileEntityLaptop) tileEntity;
			if(laptop.isOpen())
			{
				return SELECTION_BOX_OPEN;
			}
			else
			{
				return SELECTION_BOX_CLOSED;
			}
		}
		return field_185505_j;
	}

	@Override
	public void func_185477_a(IBlockState state, World worldIn, BlockPos pos, AxisAlignedBB entityBox, List<AxisAlignedBB> collidingBoxes, @Nullable Entity entityIn, boolean p_185477_7_)
	{
		TileEntity tileEntity = worldIn.func_175625_s(pos);
		if(tileEntity instanceof TileEntityLaptop)
		{
			TileEntityLaptop laptop = (TileEntityLaptop) tileEntity;
			if(laptop.isOpen())
			{
				Block.func_185492_a(pos, entityBox, collidingBoxes, BODY_OPEN_BOX);
				Block.func_185492_a(pos, entityBox, collidingBoxes, SCREEN_BOXES[state.func_177229_b(field_185512_D).func_176736_b()]);
			}
			else
			{
				Block.func_185492_a(pos, entityBox, collidingBoxes, BODY_CLOSED_BOX);
			}
			return;
		}
		Block.func_185492_a(pos, entityBox, collidingBoxes, field_185505_j);
	}

	@Override
	public boolean func_180639_a(World worldIn, BlockPos pos, IBlockState state, EntityPlayer playerIn, EnumHand hand, EnumFacing side, float hitX, float hitY, float hitZ)
	{
		TileEntity tileEntity = worldIn.func_175625_s(pos);
		if(tileEntity instanceof TileEntityLaptop)
		{
			TileEntityLaptop laptop = (TileEntityLaptop) tileEntity;

			if(playerIn.func_70093_af())
			{
				if(!worldIn.field_72995_K)
				{
					laptop.openClose();
				}
			}
			else
			{
				if(side == state.func_177229_b(field_185512_D).func_176735_f())
				{
					ItemStack heldItem = playerIn.func_184586_b(hand);
					if(!heldItem.func_190926_b() && heldItem.func_77973_b() == DeviceItems.FLASH_DRIVE)
					{
						if(!worldIn.field_72995_K)
						{
							if(laptop.getFileSystem().setAttachedDrive(heldItem.func_77946_l()))
							{
								heldItem.func_190918_g(1);
							}
							else
							{
								playerIn.func_145747_a(new TextComponentString("No more available USB slots!"));
							}
						}
						return true;
					}

					if(!worldIn.field_72995_K)
					{
						ItemStack stack = laptop.getFileSystem().removeAttachedDrive();
						if(stack != null)
						{
							BlockPos summonPos = pos.func_177972_a(state.func_177229_b(field_185512_D).func_176735_f());
							worldIn.func_72838_d(new EntityItem(worldIn, summonPos.func_177958_n() + 0.5, summonPos.func_177956_o(), summonPos.func_177952_p() + 0.5, stack));
							TileEntityUtil.markBlockForUpdate(worldIn, pos);
						}
					}
					return true;
				}

				if(laptop.isOpen() && worldIn.field_72995_K)
				{
					playerIn.openGui(MrCrayfishDeviceMod.instance, Laptop.ID, worldIn, pos.func_177958_n(), pos.func_177956_o(), pos.func_177952_p());
				}
			}
		}
		return true;
	}

	@Override
	protected void removeTagsForDrop(NBTTagCompound tileEntityTag)
	{
		tileEntityTag.func_82580_o("open");
	}
	
	@Override
	public IBlockState func_176221_a(IBlockState state, IBlockAccess worldIn, BlockPos pos) 
	{
		return super.func_176221_a(state, worldIn, pos).func_177226_a(TYPE, Type.BASE);
	}

	@Override
	public IBlockState func_176203_a(int meta)
	{
		return super.func_176203_a(meta).func_177226_a(TYPE, Type.BASE);
	}

	@Override
	protected BlockStateContainer func_180661_e()
	{
		return new BlockStateContainer(this, field_185512_D, TYPE, BlockColored.field_176581_a);
	}

	@Nullable
	@Override
	public TileEntity createTileEntity(World world, IBlockState state)
	{
		return new TileEntityLaptop();
	}

	@Override
	public BlockRenderLayer func_180664_k()
	{
		return BlockRenderLayer.CUTOUT;
	}

	public enum Type implements IStringSerializable
	{
		BASE, SCREEN;

		@Override
		public String func_176610_l() 
		{
			return name().toLowerCase();
		}
		
	}
}
