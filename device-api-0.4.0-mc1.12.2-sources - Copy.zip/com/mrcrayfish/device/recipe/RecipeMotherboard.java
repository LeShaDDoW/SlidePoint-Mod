package com.mrcrayfish.device.recipe;

import com.mrcrayfish.device.Reference;
import com.mrcrayfish.device.init.DeviceBlocks;
import com.mrcrayfish.device.init.DeviceItems;
import com.mrcrayfish.device.item.ItemMotherboard;
import net.minecraft.init.Items;
import net.minecraft.inventory.InventoryCrafting;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.crafting.IRecipe;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.ResourceLocation;
import net.minecraft.world.World;
import net.minecraftforge.common.util.Constants;

/**
 * Author: MrCrayfish
 */
public class RecipeMotherboard extends net.minecraftforge.registries.IForgeRegistryEntry.Impl<IRecipe> implements IRecipe
{
    public RecipeMotherboard()
    {
        this.setRegistryName(new ResourceLocation(Reference.MOD_ID, "motherboard_components"));
    }

    @Override
    public boolean func_77569_a(InventoryCrafting inv, World worldIn)
    {
        ItemStack motherboard = ItemStack.field_190927_a;
        ItemStack component = ItemStack.field_190927_a;

        for(int i = 0; i < inv.func_70302_i_(); i++)
        {
            ItemStack stack = inv.func_70301_a(i);
            if(!stack.func_190926_b())
            {
                if(stack.func_77973_b() == DeviceItems.COMPONENT_MOTHERBOARD)
                {
                    if(!motherboard.func_190926_b())
                        return false;
                    motherboard = stack;
                }
                else if(stack.func_77973_b() instanceof ItemMotherboard.Component)
                {
                    if(!component.func_190926_b())
                        return false;
                    component = stack;
                }
                else
                {
                    return false;
                }
            }
        }

        return !motherboard.func_190926_b() && !component.func_190926_b();
    }

    @Override
    public ItemStack func_77572_b(InventoryCrafting inv)
    {
        ItemStack motherboard = ItemStack.field_190927_a;
        ItemStack component = ItemStack.field_190927_a;

        for(int i = 0; i < inv.func_70302_i_(); i++)
        {
            ItemStack stack = inv.func_70301_a(i);
            if(!stack.func_190926_b())
            {
                if(stack.func_77973_b() == DeviceItems.COMPONENT_MOTHERBOARD)
                {
                    if(!motherboard.func_190926_b())
                        return null;
                    motherboard = stack;
                }
                else if(stack.func_77973_b() instanceof ItemMotherboard.Component)
                {
                    if(!component.func_190926_b())
                        return null;
                    component = stack;
                }
                else
                {
                    return null;
                }
            }
        }

        if(!motherboard.func_190926_b() && !component.func_190926_b())
        {
            NBTTagCompound originalTag = motherboard.func_77978_p();
            if(originalTag != null && originalTag.func_150297_b("components", Constants.NBT.TAG_COMPOUND))
            {
                NBTTagCompound tag = originalTag.func_74775_l("components");
                if(tag.func_150297_b(component.func_77977_a().substring(5), Constants.NBT.TAG_BYTE))
                {
                    return null;
                }
            }

            ItemStack result = motherboard.func_77946_l();
            if(!result.func_77942_o())
            {
                result.func_77982_d(new NBTTagCompound());
            }

            NBTTagCompound itemTag = result.func_77978_p();
            if(itemTag != null)
            {
                if(!itemTag.func_150297_b("components", Constants.NBT.TAG_COMPOUND))
                {
                    itemTag.func_74782_a("components", new NBTTagCompound());
                }

                NBTTagCompound components = itemTag.func_74775_l("components");
                components.func_74774_a(component.func_77977_a().substring(5), (byte) 0);
                return result;
            }
        }

        return null;
    }

    @Override
    public boolean func_194133_a(int width, int height)
    {
        return width * height >= 2;
    }

    @Override
    public ItemStack func_77571_b()
    {
        return ItemStack.field_190927_a;
    }

    @Override
    public boolean func_192399_d()
    {
        return true;
    }
}
