package com.mrcrayfish.device.recipe;

import com.mrcrayfish.device.Reference;
import com.mrcrayfish.device.init.DeviceBlocks;
import com.mrcrayfish.device.init.DeviceItems;
import net.minecraft.init.Items;
import net.minecraft.inventory.InventoryCrafting;
import net.minecraft.item.ItemStack;
import net.minecraft.item.crafting.IRecipe;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.ResourceLocation;
import net.minecraft.world.World;

/**
 * Author: MrCrayfish
 */
public class RecipeLaptop extends net.minecraftforge.registries.IForgeRegistryEntry.Impl<IRecipe> implements IRecipe
{
    public RecipeLaptop()
    {
        this.setRegistryName(new ResourceLocation(Reference.MOD_ID, "laptop"));
    }

    @Override
    public boolean func_77569_a(InventoryCrafting inv, World worldIn)
    {
        if(inv.func_70301_a(0).func_190926_b() || inv.func_70301_a(0).func_77973_b() != DeviceItems.PLASTIC_FRAME)
            return false;

        if(inv.func_70301_a(1).func_190926_b() || inv.func_70301_a(1).func_77973_b() != DeviceItems.COMPONENT_SCREEN)
            return false;

        if(inv.func_70301_a(2).func_190926_b() || inv.func_70301_a(2).func_77973_b() != DeviceItems.PLASTIC_FRAME)
            return false;

        if(inv.func_70301_a(3).func_190926_b() || inv.func_70301_a(3).func_77973_b() != DeviceItems.COMPONENT_BATTERY)
            return false;

        if(inv.func_70301_a(4).func_190926_b() || inv.func_70301_a(4).func_77973_b() != DeviceItems.COMPONENT_MOTHERBOARD)
            return false;

        if(inv.func_70301_a(5).func_190926_b() || inv.func_70301_a(5).func_77973_b() != DeviceItems.COMPONENT_HARD_DRIVE)
            return false;

        if(inv.func_70301_a(6).func_190926_b() || inv.func_70301_a(6).func_77973_b() != DeviceItems.PLASTIC_FRAME)
            return false;

        if(inv.func_70301_a(7).func_190926_b() || inv.func_70301_a(7).func_77973_b() != Items.field_151100_aR)
            return false;

        if(inv.func_70301_a(8).func_190926_b() || inv.func_70301_a(8).func_77973_b() != DeviceItems.PLASTIC_FRAME)
            return false;

        ItemStack motherboard = inv.func_70301_a(4);
        NBTTagCompound tag = motherboard.func_77978_p();
        if(tag != null)
        {
            NBTTagCompound components = tag.func_74775_l("components");
            return components.func_74764_b("cpu") && components.func_74764_b("ram") && components.func_74764_b("gpu") && components.func_74764_b("wifi");
        }
        return false;
    }

    @Override
    public ItemStack func_77572_b(InventoryCrafting inv)
    {
        ItemStack dye = inv.func_70301_a(7);
        return new ItemStack(DeviceBlocks.LAPTOP, 1, 15 - dye.func_77960_j());
    }

    @Override
    public boolean func_194133_a(int width, int height)
    {
        return width >= 3 && height >= 3;
    }

    @Override
    public ItemStack func_77571_b()
    {
        return ItemStack.field_190927_a;
    }
}
