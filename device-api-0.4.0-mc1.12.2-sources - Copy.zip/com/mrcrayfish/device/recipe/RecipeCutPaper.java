package com.mrcrayfish.device.recipe;

import com.mrcrayfish.device.Reference;
import com.mrcrayfish.device.init.DeviceBlocks;
import net.minecraft.init.Items;
import net.minecraft.inventory.InventoryCrafting;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.crafting.IRecipe;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.NonNullList;
import net.minecraft.util.ResourceLocation;
import net.minecraft.world.World;
import net.minecraftforge.common.util.Constants;

/**
 * Author: MrCrayfish
 */
public class RecipeCutPaper extends net.minecraftforge.registries.IForgeRegistryEntry.Impl<IRecipe> implements IRecipe
{
    public RecipeCutPaper()
    {
        this.setRegistryName(new ResourceLocation(Reference.MOD_ID, "cut_paper"));
    }

    @Override
    public boolean func_77569_a(InventoryCrafting inv, World worldIn)
    {
        ItemStack paper = ItemStack.field_190927_a;
        ItemStack shear = ItemStack.field_190927_a;

        for(int i = 0; i < inv.func_70302_i_(); i++)
        {
            ItemStack stack = inv.func_70301_a(i);
            if(!stack.func_190926_b())
            {
                if(stack.func_77973_b() == Item.func_150898_a(DeviceBlocks.PAPER))
                {
                    if(!paper.func_190926_b()) return false;
                    paper = stack;
                }

                if(stack.func_77973_b() == Items.field_151097_aZ)
                {
                    if(!shear.func_190926_b()) return false;
                    shear = stack;
                }
            }
        }

        return !paper.func_190926_b() && !shear.func_190926_b();
    }

    @Override
    public ItemStack func_77572_b(InventoryCrafting inv)
    {
        ItemStack paper = ItemStack.field_190927_a;
        for(int i = 0; i < inv.func_70302_i_(); i++)
        {
            ItemStack stack = inv.func_70301_a(i);
            if(!stack.func_190926_b())
            {
                if(stack.func_77973_b() == Item.func_150898_a(DeviceBlocks.PAPER))
                {
                    if(!paper.func_190926_b()) return ItemStack.field_190927_a;
                    paper = stack;
                }
            }
        }

        if(!paper.func_190926_b() && paper.func_77942_o())
        {
            ItemStack result = new ItemStack(DeviceBlocks.PAPER);

            NBTTagCompound tag = paper.func_77978_p();
            if(!tag.func_150297_b("BlockEntityTag", Constants.NBT.TAG_COMPOUND))
            {
                return ItemStack.field_190927_a;
            }

            NBTTagCompound blockTag = tag.func_74775_l("BlockEntityTag");
            if(!blockTag.func_150297_b("print", Constants.NBT.TAG_COMPOUND))
            {
                return ItemStack.field_190927_a;
            }

            NBTTagCompound printTag = blockTag.func_74775_l("print");
            NBTTagCompound data = printTag.func_74775_l("data");
            if(!data.func_150297_b("pixels", Constants.NBT.TAG_INT_ARRAY) || !data.func_150297_b("resolution", Constants.NBT.TAG_INT))
            {
                return ItemStack.field_190927_a;
            }
            data.func_74757_a("cut", true);
            result.func_77982_d(tag);

            return result;
        }

        return ItemStack.field_190927_a;
    }

    @Override
    public boolean func_194133_a(int width, int height)
    {
        return width * height >= 2;
    }

    @Override
    public ItemStack func_77571_b()
    {
        return ItemStack.field_190927_a;
    }

    @Override
    public NonNullList<ItemStack> func_179532_b(InventoryCrafting inv)
    {
        NonNullList<ItemStack> list = NonNullList.func_191197_a(inv.func_70302_i_(), ItemStack.field_190927_a);
        for(int i = 0; i < inv.func_70302_i_(); i++)
        {
            ItemStack stack = inv.func_70301_a(i);
            if(!stack.func_190926_b() && stack.func_77973_b() == Items.field_151097_aZ)
            {
                ItemStack copy = stack.func_77946_l();
                copy.func_190920_e(1);
                copy.func_77964_b(copy.func_77952_i() + 1);
                if(copy.func_77952_i() >= copy.func_77958_k()) break;
                list.set(i, copy);
                break;
            }
        }
        return list;
    }

    @Override
    public boolean func_192399_d()
    {
        return true;
    }
}
